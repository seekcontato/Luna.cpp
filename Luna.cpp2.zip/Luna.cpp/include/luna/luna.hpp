#pragma once

#define LUNA_VERSION_MAJOR 0
#define LUNA_VERSION_MINOR 1
#define LUNA_VERSION_PATCH 0

namespace luna {
constexpr const char* version() { return "0.1.0"; }
}
