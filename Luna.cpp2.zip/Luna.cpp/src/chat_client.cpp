#include <algorithm>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <unistd.h>
#include <vector>

#include "io/gguf.hpp"
#include "models/llama.hpp"
#include "models/llama_weights.hpp"
#include "models/forward.hpp"
#include "tokenizer/bpe.hpp"
#include "tokenizer/chat.hpp"
#include "util/model_finder.hpp"
#include "util/selector.hpp"
#include "util/memory.hpp"

using namespace luna;

static void on_signal(int) {
  const char msg[] = "\n[chat] interrompido\n";
  (void)!write(STDOUT_FILENO, msg, sizeof(msg) - 1);
  _exit(130);
}

namespace {

enum class LoadStatus { Ok, Cancelled, Failed };

struct Config {
  std::string model_path;
  std::string system = "You are a helpful AI assistant.";
  int   n_ctx       = 2048;
  int   max_gen     = 300;
  float temp        = 0.7f;
  int   top_k       = 40;
  float top_p       = 0.9f;
  float repeat_penalty = 1.15f;
  int   repeat_last_n  = 64;
  bool  no_think    = false;
  int   remember    = 10;    // últimas N trocas no prompt
};

class ChatClient {
 public:
  LoadStatus load(const Config& cfg) {
    cfg_ = cfg;

    std::string resolved = resolve_path(cfg_.model_path);
    if (resolved.empty()) return LoadStatus::Cancelled;
    if (resolved != cfg_.model_path)
      std::printf("[finder] %s -> %s\n",
                  cfg_.model_path.c_str(), resolved.c_str());
    cfg_.model_path = resolved;

    try {
      if (!file_.open(cfg_.model_path)) {
        std::fprintf(stderr, "erro: não abri %s\n", cfg_.model_path.c_str());
        return LoadStatus::Failed;
      }
      if (!tk_.load(file_)) {
        std::fprintf(stderr, "erro: tokenizer não carregou\n");
        return LoadStatus::Failed;
      }
      ct_.detect(file_);
      std::printf("[chat] formato: %s\n",
                  tokenizer::chat_format_name(ct_.format));

      if (!w_.load(file_)) {
        std::fprintf(stderr, "erro: pesos não carregaram\n");
        return LoadStatus::Failed;
      }
    } catch (const std::exception& e) {
      std::fprintf(stderr, "\n[erro] %s\n", e.what());
      std::fprintf(stderr, "\nArquitetura não suportada. Use Qwen2.5/Qwen3/Llama.\n");
      return LoadStatus::Failed;
    }

    int real_ctx = cfg_.n_ctx;
    if (w_.config.n_ctx_train > 0)
      real_ctx = std::min(real_ctx, w_.config.n_ctx_train);
    ctx_size_ = real_ctx;

    mem_.open("default");
    std::printf("[chat] memória: %zu mensagens em %s\n",
                mem_.size(), mem_.path().c_str());

    fwd_ = std::make_unique<models::LlamaForward>(w_, real_ctx);
    stops_ = ct_.stop_ids(tk_);
    think_open_id_  = tk_.token_to_id("<think>");
    think_close_id_ = tk_.token_to_id("</think>");
    return LoadStatus::Ok;
  }

  void run() {
    std::printf("\n=== Luna.cpp chat ===\n");
    std::printf("Modelo : %s\n", cfg_.model_path.c_str());
    std::printf("Ctx    : %d tokens\n", ctx_size_);
    std::printf("System : \"%s\"\n", cfg_.system.c_str());
    std::printf("Digite /help para comandos, /exit para sair.\n");

    for (;;) {
      std::printf("\n\033[1;36mvocê\033[0m: ");
      std::fflush(stdout);

      std::string line;
      if (!std::getline(std::cin, line)) { std::printf("\n"); break; }
      while (!line.empty() && (line.back() == '\n' || line.back() == '\r'))
        line.pop_back();
      if (line.empty()) continue;

      if (line[0] == '/') {
        int rc = handle_command(line);
        if (rc < 0) break;
        if (rc == 0) continue;
      }

      process_turn(line);
    }

    std::printf("\naté logo.\n");
  }

 private:
  static std::string resolve_path(const std::string& input) {
    if (input.empty()) {
      auto models = util::list_models();
      if (models.empty()) {
        std::fprintf(stderr, "Nenhum .gguf encontrado. Veja `luna-cli list`.\n");
        return "";
      }
      return util::pick_model(models, "Escolha um modelo para conversar");
    }
    std::string p = util::resolve_model(input);
    if (!p.empty()) return p;

    auto all = util::list_models();
    if (all.empty()) {
      std::fprintf(stderr, "Não encontrei \"%s\" e nenhum modelo disponível.\n",
                   input.c_str());
      return "";
    }
    std::vector<util::ModelEntry> filtered;
    for (auto& m : all)
      if (m.name.find(input) != std::string::npos ||
          m.path.find(input) != std::string::npos)
        filtered.push_back(m);
    if (filtered.empty()) filtered = all;
    return util::pick_model(filtered, "Escolha um modelo para conversar");
  }

  void print_help() {
    std::printf("Comandos:\n");
    std::printf("  /help            mostra esta ajuda\n");
    std::printf("  /reset           limpa histórico da sessão\n");
    std::printf("  /system <texto>  troca o system prompt\n");
    std::printf("  /n <n>           limite de tokens por resposta (atual %d)\n", cfg_.max_gen);
    std::printf("  /remember <n>    quantas trocas manter no prompt (atual %d)\n", cfg_.remember);
    std::printf("  /memory          mostra onde está a memória\n");
    std::printf("  /recall <termo>  busca em mensagens antigas\n");
    std::printf("  /forget          apaga a memória persistente\n");
    std::printf("  /nothink         alterna modo thinking (Qwen3)\n");
    std::printf("  /status          mostra estado atual\n");
    std::printf("  /exit ou /quit   sai\n");
  }

  void print_status() {
    std::printf("modelo   : %s\n", cfg_.model_path.c_str());
    std::printf("system   : \"%s\"\n", cfg_.system.c_str());
    std::printf("contexto : %zu / %d tokens\n", ctx_.size(), ctx_size_);
    std::printf("temp     : %.2f\n", cfg_.temp);
    std::printf("top-k    : %d\n", cfg_.top_k);
    std::printf("top-p    : %.2f\n", cfg_.top_p);
    std::printf("penalty  : %.2f (últimos %d tokens)\n",
                cfg_.repeat_penalty, cfg_.repeat_last_n);
    std::printf("max gen  : %d\n", cfg_.max_gen);
    std::printf("remember : %d trocas no prompt\n", cfg_.remember);
    std::printf("memória  : %zu mensagens em %s\n",
                mem_.size(), mem_.path().c_str());
    std::printf("nothink  : %s\n", cfg_.no_think ? "on" : "off");
  }

  void reset_session() {
    ctx_.clear();
    if (fwd_) fwd_->reset();
    std::printf("[chat] sessão reiniciada\n");
  }

  // -1 = sair, 0 = tratado, 1 = não é comando
  int handle_command(const std::string& line) {
    std::istringstream iss(line);
    std::string cmd; iss >> cmd;

    if (cmd == "/exit" || cmd == "/quit" || cmd == "/q") return -1;
    if (cmd == "/help" || cmd == "/h" || cmd == "/?") { print_help(); return 0; }
    if (cmd == "/status") { print_status(); return 0; }
    if (cmd == "/reset") { reset_session(); return 0; }

    if (cmd == "/system") {
      std::string rest;
      std::getline(iss, rest);
      if (!rest.empty() && rest[0] == ' ') rest = rest.substr(1);
      cfg_.system = rest;
      std::printf("[chat] system atualizado\n");
      reset_session();
      return 0;
    }
    if (cmd == "/temp") { float v; if (iss >> v) cfg_.temp = v;
      std::printf("[chat] temp = %.2f\n", cfg_.temp); return 0; }
    if (cmd == "/topk") { int v; if (iss >> v) cfg_.top_k = v;
      std::printf("[chat] top-k = %d\n", cfg_.top_k); return 0; }
    if (cmd == "/topp") { float v; if (iss >> v) cfg_.top_p = v;
      std::printf("[chat] top-p = %.2f\n", cfg_.top_p); return 0; }
    if (cmd == "/penalty") { float v; if (iss >> v) cfg_.repeat_penalty = v;
      std::printf("[chat] penalty = %.2f\n", cfg_.repeat_penalty); return 0; }
    if (cmd == "/n") { int v; if (iss >> v) cfg_.max_gen = v;
      std::printf("[chat] max gen = %d\n", cfg_.max_gen); return 0; }
    if (cmd == "/remember") { int v; if (iss >> v) cfg_.remember = v > 0 ? v : 1;
      std::printf("[chat] remember = %d trocas\n", cfg_.remember); return 0; }
    if (cmd == "/nothink") {
      cfg_.no_think = !cfg_.no_think;
      std::printf("[chat] nothink = %s\n", cfg_.no_think ? "on" : "off");
      return 0;
    }
    if (cmd == "/memory") {
      std::printf("[chat] %zu mensagens em %s\n", mem_.size(), mem_.path().c_str());
      return 0;
    }
    if (cmd == "/recall") {
      std::string term;
      std::getline(iss, term);
      if (!term.empty() && term[0] == ' ') term = term.substr(1);
      if (term.empty()) { std::printf("[chat] uso: /recall <termo>\n"); return 0; }
      auto hits = mem_.search(term);
      if (hits.empty()) { std::printf("[chat] nada encontrado\n"); return 0; }
      std::printf("[chat] %zu resultado(s):\n", hits.size());
      for (auto& e : hits)
        std::printf("  [%s] %s: %.100s\n",
                    e.ts.c_str(), e.role.c_str(), e.content.c_str());
      return 0;
    }
    if (cmd == "/forget") {
      mem_.clear();
      std::printf("[chat] memória apagada\n");
      return 0;
    }

    std::printf("[chat] comando desconhecido: %s (tente /help)\n", cmd.c_str());
    return 0;
  }

  // ---- Constrói o prompt incluindo memória persistente ----
  std::vector<int32_t> build_prompt_with_history(const std::string& user) {
    // Pega as últimas `remember` trocas (user+assistant pares) da memória
    auto recent = mem_.last(cfg_.remember * 2);

    // Separa em pares user/assistant
    struct Pair { std::string user, assistant; };
    std::vector<Pair> pairs;
    Pair cur;
    for (auto& e : recent) {
      if (e.role == "user") {
        if (!cur.user.empty()) {
          pairs.push_back(cur);
          cur = Pair{};
        }
        cur.user = e.content;
      } else if (e.role == "assistant") {
        cur.assistant = e.content;
        pairs.push_back(cur);
        cur = Pair{};
      }
    }
    if (!cur.user.empty()) pairs.push_back(cur);

    // Remove a última troca se for o mesmo user que acabamos de receber
    if (!pairs.empty() && pairs.back().user == user && pairs.back().assistant.empty())
      pairs.pop_back();

    // Monta prompt
    std::vector<int32_t> prompt;
    if (pairs.empty()) {
      prompt = ct_.build_prompt(tk_, cfg_.system, user);
    } else {
      prompt = ct_.build_prompt(tk_, cfg_.system, pairs[0].user);
      for (size_t i = 0; i < pairs.size(); ++i) {
        if (i > 0) {
          auto ids = ct_.next_turn(tk_, pairs[i].user);
          prompt.insert(prompt.end(), ids.begin(), ids.end());
        } else {
          // O primeiro build_prompt já inclui o user + marcador de assistant.
          // Não precisamos duplicar.
        }
        if (!pairs[i].assistant.empty()) {
          auto a = tk_.encode(pairs[i].assistant, false);
          prompt.insert(prompt.end(), a.begin(), a.end());
          for (auto s : stops_) prompt.push_back(s);
        }
      }
      // Adiciona o turno atual
      auto now = ct_.next_turn(tk_, user);
      prompt.insert(prompt.end(), now.begin(), now.end());
    }
    return prompt;
  }

  std::vector<float> feed_tokens(const std::vector<int32_t>& ids) {
    std::vector<float> logits;
    for (size_t i = 0; i < ids.size(); ++i) {
      int32_t pos = (int32_t)ctx_.size();
      if (pos >= ctx_size_) break;
      logits = fwd_->forward_token(ids[i], pos);
      ctx_.push_back(ids[i]);
    }
    return logits;
  }

  void process_turn(const std::string& user_in) {
    std::string user = user_in;
    if (cfg_.no_think && user.find("/no_think") == std::string::npos)
      user += " /no_think";

    // Grava o user imediatamente
    mem_.append("user", user_in);

    // Constrói prompt com histórico
    auto prompt_ids = build_prompt_with_history(user_in);
    if (prompt_ids.empty()) return;

    auto logits = feed_tokens(prompt_ids);
    if (logits.empty()) return;

    std::printf("\033[1;32mluna\033[0m: ");
    std::fflush(stdout);

    models::SampleOpts opts;
    opts.temp           = cfg_.temp;
    opts.top_k          = cfg_.top_k;
    opts.top_p          = cfg_.top_p;
    opts.repeat_penalty = cfg_.repeat_penalty;
    opts.repeat_last_n  = cfg_.repeat_last_n;

    uint64_t rng = 0xDEADBEEFCAFEBABEULL;
    bool in_think = false;
    std::string reply;
    int emitted = 0;

    for (int step = 0; step < cfg_.max_gen; ++step) {
      int32_t next = models::sample(logits, ctx_, opts, rng);
      bool is_stop = false;
      for (auto s : stops_) if (s == next) { is_stop = true; break; }
      if (is_stop) { ctx_.push_back(next); break; }

      if (next == think_open_id_)  in_think = true;
      if (next == think_close_id_) in_think = false;

      const bool is_marker = (next == think_open_id_ ||
                              next == think_close_id_);
      if (!in_think && !is_marker) {
        std::string piece = tk_.decode_one(next);
        std::printf("%s", piece.c_str());
        std::fflush(stdout);
        reply += piece;
        ++emitted;
      }
      ctx_.push_back(next);

      int32_t pos = (int32_t)ctx_.size() - 1;
      if (pos + 1 >= ctx_size_) { std::printf("\n[chat] contexto cheio\n"); break; }
      logits = fwd_->forward_token(next, pos);
    }
    std::printf("\n");

    if (emitted == 0) {
      std::printf("[chat] (modelo pensou mas não emitiu resposta visível)\n");
    } else {
      // Grava a resposta na memória persistente
      mem_.append("assistant", reply);
    }
  }

  Config cfg_;
  util::Memory mem_;
  io::GgufFile file_;
  tokenizer::BpeTokenizer tk_;
  tokenizer::ChatTemplate ct_;
  models::LlamaWeights w_;
  std::unique_ptr<models::LlamaForward> fwd_;
  std::vector<int32_t> ctx_;
  std::vector<int32_t> stops_;
  int32_t think_open_id_  = -1;
  int32_t think_close_id_ = -1;
  int  ctx_size_ = 2048;
};

void usage(const char* a) {
  std::printf("Uso: %s [modelo|nome-parcial] [flags]\n", a);
  std::printf("Sem argumento: abre o seletor.\n\n");
  std::printf("Flags:\n");
  std::printf("  --system <txt>   system prompt\n");
  std::printf("  --temp <n>       temperatura (0.7)\n");
  std::printf("  --topk <n>       top-k (40)\n");
  std::printf("  --topp <n>       top-p (0.9)\n");
  std::printf("  --penalty <n>    repetition penalty (1.15)\n");
  std::printf("  --n <n>          tokens por resposta (300)\n");
  std::printf("  --ctx <n>        contexto (2048)\n");
}

}  // namespace

int main(int argc, char** argv) {
  Config cfg;
  bool need_pick = (argc < 2) || (argv[1][0] == '-');
  int i = 1;
  if (!need_pick) { cfg.model_path = argv[1]; i = 2; }

  for (; i < argc; ++i) {
    if (std::strcmp(argv[i], "--system") == 0 && i+1 < argc) cfg.system = argv[++i];
    else if (std::strcmp(argv[i], "--temp") == 0 && i+1 < argc) cfg.temp = (float)std::atof(argv[++i]);
    else if (std::strcmp(argv[i], "--topk") == 0 && i+1 < argc) cfg.top_k = std::atoi(argv[++i]);
    else if (std::strcmp(argv[i], "--topp") == 0 && i+1 < argc) cfg.top_p = (float)std::atof(argv[++i]);
    else if (std::strcmp(argv[i], "--penalty") == 0 && i+1 < argc) cfg.repeat_penalty = (float)std::atof(argv[++i]);
    else if (std::strcmp(argv[i], "--n") == 0 && i+1 < argc) cfg.max_gen = std::atoi(argv[++i]);
    else if (std::strcmp(argv[i], "--ctx") == 0 && i+1 < argc) cfg.n_ctx = std::atoi(argv[++i]);
    else if (std::strcmp(argv[i], "--help") == 0 || std::strcmp(argv[i], "-h") == 0) {
      usage(argv[0]); return 0;
    }
    else { std::fprintf(stderr, "opção desconhecida: %s\n", argv[i]); usage(argv[0]); return 1; }
  }

  std::signal(SIGINT,  on_signal);
  std::signal(SIGTERM, on_signal);

  bool first_attempt = true;
  for (;;) {
    ChatClient client;
    auto st = client.load(cfg);
    if (st == LoadStatus::Ok) { client.run(); return 0; }
    if (st == LoadStatus::Cancelled) return 1;
    if (!first_attempt) {
      std::printf("\nPressione Enter para escolher outro modelo, ou Ctrl+C para sair.\n");
      std::string dummy;
      if (!std::getline(std::cin, dummy)) return 1;
    }
    first_attempt = false;
    cfg.model_path = "";
  }
}
