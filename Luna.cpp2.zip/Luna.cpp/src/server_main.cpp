#include <atomic>
#include <csignal>
#include <unistd.h>
#include <unistd.h>
#include <sys/signal.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>

#include "server/http_server.hpp"
#include "server/openai_api.hpp"
#include "util/model_finder.hpp"
#include "util/selector.hpp"

using namespace luna;

static std::atomic<bool> g_running{true};
static server::HttpServer* g_http = nullptr;

static void on_signal(int) {
  g_running = false;
  if (g_http) g_http->stop();
}

static void install_signals() {
  struct sigaction sa{};
  sa.sa_handler = on_signal;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = 0;   // sem SA_RESTART: queremos que select() retorne EINTR
  sigaction(SIGINT,  &sa, nullptr);
  sigaction(SIGTERM, &sa, nullptr);
}

static void usage(const char* a) {
  std::printf("Luna.cpp server v0.3\n");
  std::printf("Uso: %s [modelo|nome-parcial] [flags]\n", a);
  std::printf("Sem argumento: abre o seletor de modelos.\n\n");
  std::printf("Flags:\n");
  std::printf("  --port <n>       porta HTTP (padrão 8080)\n");
  std::printf("  --system <txt>   system prompt\n");
  std::printf("  --ctx <n>        contexto (padrão 2048)\n");
  std::printf("  --n <n>          tokens por resposta (padrão 512)\n");
  std::printf("  --id <nome>      id do modelo exposto na API\n");
}

static std::string resolve_path(const std::string& input) {
  if (input.empty()) {
    auto models = util::list_models();
    if (models.empty()) {
      std::fprintf(stderr, "Nenhum .gguf encontrado. Veja `luna-cli list`.\n");
      return "";
    }
    return util::pick_model(models, "Escolha um modelo para o servidor");
  }
  std::string p = util::resolve_model(input);
  if (!p.empty()) return p;
  auto models = util::list_models();
  if (models.empty()) return "";
  std::fprintf(stderr, "Não achei \"%s\". Abrindo lista...\n", input.c_str());
  return util::pick_model(models, "Escolha um modelo para o servidor");
}

// ---- Página HTML do chat ----
static const char* CHAT_HTML = R"HTML(<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Luna.cpp chat</title>
<style>
  :root {
    --bg:#0f1115; --fg:#e6e6e6; --accent:#7cc4ff; --user:#1e3a5f; --luna:#1a1d22;
    --border:#2a2f3a;
  }
  * { box-sizing:border-box; }
  html,body { margin:0; height:100%; background:var(--bg); color:var(--fg);
    font:15px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif; }
  header { padding:12px 16px; border-bottom:1px solid var(--border);
    display:flex; align-items:center; gap:12px; }
  header h1 { font-size:16px; margin:0; color:var(--accent); }
  header .meta { font-size:12px; color:#888; margin-left:auto; }
  #log { padding:16px; overflow-y:auto; height:calc(100% - 120px); }
  .msg { margin:0 0 14px; display:flex; }
  .msg .bubble { padding:10px 14px; border-radius:12px; max-width:min(680px,88%);
    white-space:pre-wrap; word-wrap:break-word; }
  .msg.user { justify-content:flex-end; }
  .msg.user .bubble { background:var(--user); }
  .msg.luna .bubble { background:var(--luna); border:1px solid var(--border); }
  .msg.sys  .bubble { background:#3a1f1f; border:1px solid #552; color:#fbb; }
  footer { position:fixed; bottom:0; left:0; right:0;
    border-top:1px solid var(--border); padding:10px 12px;
    background:var(--bg); display:flex; gap:8px; }
  textarea { flex:1; resize:none; padding:10px 12px; border-radius:10px;
    background:#161a20; color:var(--fg); border:1px solid var(--border);
    font:inherit; outline:none; min-height:44px; max-height:160px; }
  textarea:focus { border-color:var(--accent); }
  button { padding:0 18px; border-radius:10px; border:0;
    background:var(--accent); color:#001; font-weight:600; cursor:pointer;
    font:inherit; height:44px; }
  button:disabled { opacity:.5; cursor:wait; }
  .controls { display:flex; gap:8px; padding:0 16px 8px;
    font-size:12px; color:#888; align-items:center; }
  .controls label { display:flex; gap:4px; align-items:center; }
  .controls input { width:60px; background:#161a20; color:var(--fg);
    border:1px solid var(--border); border-radius:6px; padding:2px 6px;
    font:inherit; }
</style>
</head>
<body>
<header>
  <h1>Luna.cpp</h1>
  <span class="meta" id="model">carregando…</span>
</header>
<div id="log"></div>
<div class="controls">
  <label>temp <input id="temp" type="number" min="0" max="2" step="0.05" value="0.7"></label>
  <label>top-k <input id="topk" type="number" min="0" max="200" step="1" value="40"></label>
  <label>top-p <input id="topp" type="number" min="0" max="1" step="0.01" value="0.9"></label>
  <label>penalty <input id="pen" type="number" min="0.5" max="2" step="0.05" value="1.15"></label>
  <button id="clear" style="margin-left:auto;background:#2a2f3a;color:#ddd">limpar</button>
</div>
<footer>
  <textarea id="in" placeholder="Digite e Enter para enviar (Shift+Enter = nova linha)"></textarea>
  <button id="send">Enviar</button>
</footer>

<script>
const log = document.getElementById('log');
const input = document.getElementById('in');
const sendBtn = document.getElementById('send');
const clearBtn = document.getElementById('clear');
const modelEl = document.getElementById('model');

const messages = [];   // histórico no formato OpenAI
let busy = false;

function addMsg(role, text) {
  const div = document.createElement('div');
  div.className = 'msg ' + role;
  const b = document.createElement('div');
  b.className = 'bubble';
  b.textContent = text;
  div.appendChild(b);
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
  return b;
}

function addSys(text) {
  const div = document.createElement('div');
  div.className = 'msg sys';
  const b = document.createElement('div');
  b.className = 'bubble';
  b.textContent = text;
  div.appendChild(b);
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
}

async function loadModel() {
  try {
    const r = await fetch('/v1/models');
    const j = await r.json();
    modelEl.textContent = j.data[0].id;
  } catch {
    modelEl.textContent = '(offline)';
  }
}

async function send() {
  if (busy) return;
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  input.style.height = 'auto';

  messages.push({ role: 'user', content: text });
  addMsg('user', text);

  const bubble = addMsg('luna', '');
  busy = true;
  sendBtn.disabled = true;

  const body = {
    messages,
    stream: true,
    temperature: parseFloat(document.getElementById('temp').value),
    top_k: parseInt(document.getElementById('topk').value, 10),
    top_p: parseFloat(document.getElementById('topp').value),
    // penalty fica no servidor por ora
  };

  try {
    const r = await fetch('/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!r.ok || !r.body) throw new Error('HTTP ' + r.status);

    const reader = r.body.getReader();
    const dec = new TextDecoder();
    let buf = '';
    let acc = '';

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let idx;
      while ((idx = buf.indexOf('\n\n')) >= 0) {
        const chunk = buf.slice(0, idx); buf = buf.slice(idx + 2);
        for (const line of chunk.split('\n')) {
          if (!line.startsWith('data:')) continue;
          const payload = line.slice(5).trim();
          if (payload === '[DONE]') break;
          try {
            const j = JSON.parse(payload);
            const d = j.choices?.[0]?.delta?.content;
            if (d) { acc += d; bubble.textContent = acc;
              log.scrollTop = log.scrollHeight; }
          } catch {}
        }
      }
    }
    messages.push({ role: 'assistant', content: acc });
  } catch (e) {
    bubble.textContent = 'erro: ' + e.message;
    addSys('erro de rede: ' + e.message);
  } finally {
    busy = false;
    sendBtn.disabled = false;
    input.focus();
  }
}

sendBtn.onclick = send;
input.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
});
input.addEventListener('input', () => {
  input.style.height = 'auto';
  input.style.height = Math.min(input.scrollHeight, 160) + 'px';
});
clearBtn.onclick = () => {
  if (busy) return;
  messages.length = 0;
  log.innerHTML = '';
  addSys('histórico limpo');
};

loadModel();
input.focus();
</script>
</body>
</html>
)HTML";

int main(int argc, char** argv) {
  server::ServerConfig cfg;
  int port = 8080;

  bool need_pick = (argc < 2) || (argv[1][0] == '-');
  int i = 1;
  if (!need_pick) { cfg.model_path = argv[1]; i = 2; }

  for (; i < argc; ++i) {
    if (std::strcmp(argv[i], "--port") == 0 && i+1 < argc) port = std::atoi(argv[++i]);
    else if (std::strcmp(argv[i], "--system") == 0 && i+1 < argc) cfg.system = argv[++i];
    else if (std::strcmp(argv[i], "--ctx") == 0 && i+1 < argc) cfg.n_ctx = std::atoi(argv[++i]);
    else if (std::strcmp(argv[i], "--n") == 0 && i+1 < argc) cfg.max_gen = std::atoi(argv[++i]);
    else if (std::strcmp(argv[i], "--id") == 0 && i+1 < argc) cfg.model_id = argv[++i];
    else if (std::strcmp(argv[i], "--help") == 0 || std::strcmp(argv[i], "-h") == 0) {
      usage(argv[0]); return 0;
    }
    else {
      std::fprintf(stderr, "opção desconhecida: %s\n", argv[i]);
      usage(argv[0]); return 1;
    }
  }

  std::string resolved = resolve_path(cfg.model_path);
  if (resolved.empty()) return 1;
  cfg.model_path = resolved;

  std::printf("=== Luna.cpp server ===\n");
  std::printf("Modelo : %s\n", cfg.model_path.c_str());
  std::printf("Porta  : %d\n", port);

  server::OpenAiApi api;
  try {
    if (!api.load(cfg)) return 2;
  } catch (const std::exception& e) {
    std::fprintf(stderr, "\n[erro] %s\n", e.what());
    std::fprintf(stderr, "Esse GGUF usa arquitetura não suportada (Gemma-3, LFM2, etc.).\n");
    return 3;
  }

  server::HttpServer http(port);
  g_http = &http;

  // Página HTML na raiz
  http.route("GET", "/", [](const server::HttpRequest&){
    server::HttpResponse r;
    r.content_type = "text/html; charset=utf-8";
    r.body = CHAT_HTML;
    return r;
  });

  http.route("GET", "/v1/models", [&](const server::HttpRequest&){
    server::HttpResponse r;
    r.body = api.handle_models();
    return r;
  });

  http.route("GET", "/health", [](const server::HttpRequest&){
    server::HttpResponse r;
    r.body = "{\"status\":\"ok\"}";
    return r;
  });

  http.route("POST", "/v1/chat/completions", [&](const server::HttpRequest& req){
    server::HttpResponse r;
    r.body = api.handle_chat_completions(req.body, false);
    return r;
  });

  http.route("POST", "/v1/completions", [&](const server::HttpRequest& req){
    server::HttpResponse r;
    r.body = api.handle_completions(req.body);
    return r;
  });

  http.route_stream("POST", "/v1/chat/completions",
                    [&](const server::HttpRequest& req,
                        std::function<void(const std::string&)> write){
                      api.handle_chat_stream(req.body, write);
                    });

  install_signals();

  std::printf("\nAbra no navegador:\n");
  std::printf("  http://localhost:%d\n\n", port);
  std::printf("Para acessar de outro dispositivo na mesma rede:\n");
  std::printf("  http://<ip-do-celular>:%d\n\n", port);
  std::printf("Ctrl+C para parar.\n\n");

  http.start();
  std::fflush(stdout); std::fflush(stderr); _exit(0);

  // Shutdown explícito: pula destrutores estáticos (evita ordem indefinida
  // entre ThreadPool e threads de cliente HTTP ainda ativas).
  std::fflush(stdout);
  std::fflush(stderr);
  _exit(0);
}
