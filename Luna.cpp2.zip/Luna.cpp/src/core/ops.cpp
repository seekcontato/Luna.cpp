#include "core/ops.hpp"

#include <cmath>
#include <stdexcept>

namespace luna::core {
namespace ops {

void matmul(const Tensor& A, const Tensor& B, Tensor& C) {
  if (A.rank() != 2 || B.rank() != 2 || C.rank() != 2)
    throw std::runtime_error("matmul: rank deve ser 2");
  if (A.dtype() != DType::F32 || B.dtype() != DType::F32 || C.dtype() != DType::F32)
    throw std::runtime_error("matmul: só suporta F32 por ora");

  const int64_t M  = A.shape()[0];
  const int64_t K  = A.shape()[1];
  const int64_t K2 = B.shape()[0];
  const int64_t N  = B.shape()[1];

  if (K != K2) throw std::runtime_error("matmul: K incompatível");
  if (C.shape()[0] != M || C.shape()[1] != N)
    throw std::runtime_error("matmul: C com shape errado");

  const float* a = A.ptr<float>();
  const float* b = B.ptr<float>();
  float*       c = C.ptr<float>();

  for (int64_t i = 0; i < M; ++i) {
    for (int64_t j = 0; j < N; ++j) {
      float acc = 0.0f;
      for (int64_t k = 0; k < K; ++k) {
        acc += a[i * K + k] * b[k * N + j];
      }
      c[i * N + j] = acc;
    }
  }
}

void rmsnorm(const Tensor& x, const Tensor& weight, Tensor& out, float eps) {
  if (x.dtype() != DType::F32) throw std::runtime_error("rmsnorm: só F32");
  if (x.rank() < 1) throw std::runtime_error("rmsnorm: rank >= 1");

  const int64_t D = x.shape().back();
  if ((int64_t)weight.numel() != D)
    throw std::runtime_error("rmsnorm: weight com tamanho errado");
  if (out.numel() != x.numel())
    throw std::runtime_error("rmsnorm: out com tamanho errado");

  const size_t rows = x.numel() / (size_t)D;
  const float* xp = x.ptr<float>();
  const float* wp = weight.ptr<float>();
  float*       op = out.ptr<float>();

  for (size_t r = 0; r < rows; ++r) {
    const float* xr = xp + r * (size_t)D;
    float*       orow = op + r * (size_t)D;

    float ss = 0.0f;
    for (int64_t i = 0; i < D; ++i) ss += xr[i] * xr[i];
    ss /= (float)D;

    const float inv = 1.0f / std::sqrt(ss + eps);
    for (int64_t i = 0; i < D; ++i) orow[i] = xr[i] * inv * wp[i];
  }
}

void silu(const Tensor& x, Tensor& out) {
  if (x.numel() != out.numel())
    throw std::runtime_error("silu: tamanhos diferentes");
  const float* xp = x.ptr<float>();
  float*       op = out.ptr<float>();
  const size_t n = x.numel();
  for (size_t i = 0; i < n; ++i) {
    const float v = xp[i];
    op[i] = v / (1.0f + std::exp(-v));
  }
}

void softmax(const Tensor& x, Tensor& out) {
  if (x.numel() != out.numel())
    throw std::runtime_error("softmax: tamanhos diferentes");
  if (x.rank() < 1) throw std::runtime_error("softmax: rank >= 1");

  const int64_t D = x.shape().back();
  const size_t rows = x.numel() / (size_t)D;
  const float* xp = x.ptr<float>();
  float*       op = out.ptr<float>();

  for (size_t r = 0; r < rows; ++r) {
    const float* xr = xp + r * (size_t)D;
    float*       orow = op + r * (size_t)D;

    float m = xr[0];
    for (int64_t i = 1; i < D; ++i) if (xr[i] > m) m = xr[i];

    float s = 0.0f;
    for (int64_t i = 0; i < D; ++i) {
      orow[i] = std::exp(xr[i] - m);
      s += orow[i];
    }
    const float inv = 1.0f / s;
    for (int64_t i = 0; i < D; ++i) orow[i] *= inv;
  }
}

void rope_inplace(Tensor& x, int pos, float theta) {
  if (x.dtype() != DType::F32) throw std::runtime_error("rope: só F32");
  if (x.rank() != 2) throw std::runtime_error("rope: rank 2 (n_heads, head_dim)");

  const int64_t n_heads  = x.shape()[0];
  const int64_t head_dim = x.shape()[1];
  if (head_dim % 2 != 0) throw std::runtime_error("rope: head_dim deve ser par");

  const int64_t half = head_dim / 2;
  float* p = x.ptr<float>();

  for (int64_t h = 0; h < n_heads; ++h) {
    float* head = p + h * head_dim;
    for (int64_t i = 0; i < half; ++i) {
      const float freq  = 1.0f / std::pow(theta, (float)(2 * i) / (float)head_dim);
      const float angle = (float)pos * freq;
      const float c = std::cos(angle);
      const float s = std::sin(angle);

      const float x0 = head[i];
      const float x1 = head[i + half];
      head[i]        = x0 * c - x1 * s;
      head[i + half] = x0 * s + x1 * c;
    }
  }
}

void add(const Tensor& a, const Tensor& b, Tensor& out) {
  if (a.numel() != b.numel() || a.numel() != out.numel())
    throw std::runtime_error("add: tamanhos diferentes");
  const float* ap = a.ptr<float>();
  const float* bp = b.ptr<float>();
  float*       op = out.ptr<float>();
  const size_t n = a.numel();
  for (size_t i = 0; i < n; ++i) op[i] = ap[i] + bp[i];
}

}  // namespace ops
}  // namespace luna::core
