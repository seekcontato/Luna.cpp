#pragma once

#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <functional>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

namespace luna::core {

class ThreadPool {
 public:
  static ThreadPool& instance();

  // Executa f(i) para i em [0, n) paralelizado em N threads
  void parallel_for(int n, const std::function<void(int)>& f);

  int n_threads() const { return (int)threads_.size(); }

 private:
  ThreadPool();
  ~ThreadPool();
  ThreadPool(const ThreadPool&) = delete;
  ThreadPool& operator=(const ThreadPool&) = delete;

  void worker_loop();

  std::vector<std::thread> threads_;
  std::mutex mu_;
  std::condition_variable cv_;
  std::queue<std::function<void()>> queue_;
  bool stop_ = false;
};

}  // namespace luna::core
