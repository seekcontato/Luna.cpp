#include "core/threadpool.hpp"

#include <algorithm>

namespace luna::core {

ThreadPool& ThreadPool::instance() {
  static ThreadPool pool;
  return pool;
}

ThreadPool::ThreadPool() {
  int n = (int)std::thread::hardware_concurrency();
  if (n <= 0) n = 1;
  // Deixa 1 core livre para o sistema
  if (n > 1) n -= 1;
  n = std::min(n, 8);
  threads_.reserve(n);
  for (int i = 0; i < n; ++i)
    threads_.emplace_back([this]{ worker_loop(); });
}

ThreadPool::~ThreadPool() {
  {
    std::lock_guard<std::mutex> lk(mu_);
    stop_ = true;
  }
  cv_.notify_all();
  for (auto& t : threads_) if (t.joinable()) t.join();
}

void ThreadPool::worker_loop() {
  for (;;) {
    std::function<void()> job;
    {
      std::unique_lock<std::mutex> lk(mu_);
      cv_.wait(lk, [this]{ return stop_ || !queue_.empty(); });
      if (stop_ && queue_.empty()) return;
      job = std::move(queue_.front());
      queue_.pop();
    }
    job();
  }
}

void ThreadPool::parallel_for(int n, const std::function<void(int)>& f) {
  if (n <= 0) return;

  const int nt = (int)threads_.size();
  if (nt <= 1 || n < 4) {
    for (int i = 0; i < n; ++i) f(i);
    return;
  }

  // Divide [0,n) em nt blocos; dispara nt-1 tarefas e roda a última aqui
  std::atomic<int> remaining{nt - 1};
  std::mutex done_mu;
  std::condition_variable done_cv;

  auto finish_one = [&]{
    if (remaining.fetch_sub(1) == 1) {
      std::lock_guard<std::mutex> lk(done_mu);
      done_cv.notify_one();
    }
  };

  const int chunk = (n + nt - 1) / nt;

  for (int t = 0; t < nt - 1; ++t) {
    const int lo = t * chunk;
    const int hi = std::min(lo + chunk, n);
    if (lo >= hi) { finish_one(); continue; }
    {
      std::lock_guard<std::mutex> lk(mu_);
      queue_.push([lo, hi, &f, &finish_one]{
        for (int i = lo; i < hi; ++i) f(i);
        finish_one();
      });
    }
    cv_.notify_one();
  }

  const int lo = (nt - 1) * chunk;
  const int hi = std::min(lo + chunk, n);
  if (lo < hi) for (int i = lo; i < hi; ++i) f(i);
  else finish_one();

  std::unique_lock<std::mutex> lk(done_mu);
  done_cv.wait(lk, [&]{ return remaining.load() == 0; });
}

}  // namespace luna::core
