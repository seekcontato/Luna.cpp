#pragma once

#include "core/tensor.hpp"

namespace luna::core {
namespace ops {

// C = A @ B   (A: [M, K], B: [K, N], C: [M, N])
void matmul(const Tensor& A, const Tensor& B, Tensor& C);

// out = x * weight / rms(x)   (normaliza no último eixo)
void rmsnorm(const Tensor& x, const Tensor& weight, Tensor& out, float eps = 1e-5f);

// out = x * sigmoid(x)
void silu(const Tensor& x, Tensor& out);

// softmax no último eixo
void softmax(const Tensor& x, Tensor& out);

// RoPE in-place, x: [n_heads, head_dim], aplica em cada head na posição `pos`
void rope_inplace(Tensor& x, int pos, float theta = 10000.0f);

// Utilitário: soma elemento a elemento
void add(const Tensor& a, const Tensor& b, Tensor& out);

}  // namespace ops
}  // namespace luna::core
