#pragma once

#include <cstddef>
#include <cstdint>
#include <initializer_list>
#include <string>
#include <vector>

namespace luna::core {

enum class DType : uint8_t {
  F32,
  F16,
  BF16,
  I8,
  I32,
};

size_t dtype_size(DType t);
const char* dtype_name(DType t);

class Tensor {
 public:
  Tensor() = default;

  Tensor(std::vector<int64_t> shape, DType dtype = DType::F32);

  Tensor(std::initializer_list<int64_t> shape, DType dtype = DType::F32)
      : Tensor(std::vector<int64_t>(shape), dtype) {}

  ~Tensor();

  // Sem cópia (evita duplicar buffer); use clone() se precisar
  Tensor(const Tensor&) = delete;
  Tensor& operator=(const Tensor&) = delete;

  // Mover é permitido
  Tensor(Tensor&& other) noexcept;
  Tensor& operator=(Tensor&& other) noexcept;

  static Tensor view(void* data,
                     std::vector<int64_t> shape,
                     std::vector<int64_t> strides,
                     DType dtype = DType::F32);

  Tensor clone() const;

  const std::vector<int64_t>& shape()   const { return shape_; }
  const std::vector<int64_t>& strides() const { return strides_; }
  DType dtype() const { return dtype_; }
  size_t rank() const { return shape_.size(); }
  size_t numel() const { return numel_; }
  size_t nbytes() const { return numel_ * dtype_size(dtype_); }

  int64_t size(int dim) const { return shape_.at(static_cast<size_t>(dim)); }

  void*       data()       { return data_; }
  const void* data() const { return data_; }

  template <typename T = float>
  T* ptr() { return reinterpret_cast<T*>(data_); }

  template <typename T = float>
  const T* ptr() const { return reinterpret_cast<const T*>(data_); }

  float& at(size_t i);
  float  at(size_t i) const;

  float& at(std::initializer_list<int64_t> idx);
  float  at(std::initializer_list<int64_t> idx) const;

  void fill(float v);
  void zero() { fill(0.0f); }

  float  min() const;
  float  max() const;
  double mean() const;
  double l2norm() const;

  std::string repr() const;
  bool owns_data() const { return owns_; }

 private:
  void recompute_strides();
  void allocate();
  void deallocate();

  std::vector<int64_t> shape_;
  std::vector<int64_t> strides_;
  DType  dtype_ = DType::F32;
  size_t numel_ = 0;
  void*  data_  = nullptr;
  bool   owns_  = false;
};

Tensor zeros(std::vector<int64_t> shape, DType dtype = DType::F32);
Tensor ones (std::vector<int64_t> shape, DType dtype = DType::F32);
Tensor empty(std::vector<int64_t> shape, DType dtype = DType::F32);

}  // namespace luna::core
