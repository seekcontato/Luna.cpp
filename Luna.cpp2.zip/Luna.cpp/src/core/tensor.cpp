#include "core/tensor.hpp"

#include <cmath>
#include <cstdlib>
#include <cstring>
#include <limits>
#include <sstream>
#include <stdexcept>

namespace luna::core {

size_t dtype_size(DType t) {
  switch (t) {
    case DType::F32:  return 4;
    case DType::F16:  return 2;
    case DType::BF16: return 2;
    case DType::I8:   return 1;
    case DType::I32:  return 4;
  }
  return 0;
}

const char* dtype_name(DType t) {
  switch (t) {
    case DType::F32:  return "F32";
    case DType::F16:  return "F16";
    case DType::BF16: return "BF16";
    case DType::I8:   return "I8";
    case DType::I32:  return "I32";
  }
  return "?";
}

Tensor::Tensor(std::vector<int64_t> shape, DType dtype)
    : shape_(std::move(shape)), dtype_(dtype), owns_(true) {
  for (auto d : shape_) {
    if (d < 0) throw std::runtime_error("Tensor: dimensão negativa");
  }
  recompute_strides();
  allocate();
}

Tensor::~Tensor() { deallocate(); }

Tensor::Tensor(Tensor&& other) noexcept
    : shape_(std::move(other.shape_)),
      strides_(std::move(other.strides_)),
      dtype_(other.dtype_),
      numel_(other.numel_),
      data_(other.data_),
      owns_(other.owns_) {
  other.data_  = nullptr;
  other.numel_ = 0;
  other.owns_  = false;
}

Tensor& Tensor::operator=(Tensor&& other) noexcept {
  if (this != &other) {
    deallocate();
    shape_   = std::move(other.shape_);
    strides_ = std::move(other.strides_);
    dtype_   = other.dtype_;
    numel_   = other.numel_;
    data_    = other.data_;
    owns_    = other.owns_;
    other.data_  = nullptr;
    other.numel_ = 0;
    other.owns_  = false;
  }
  return *this;
}

Tensor Tensor::view(void* data,
                    std::vector<int64_t> shape,
                    std::vector<int64_t> strides,
                    DType dtype) {
  Tensor t;
  t.shape_   = std::move(shape);
  t.strides_ = std::move(strides);
  t.dtype_   = dtype;
  t.data_    = data;
  t.owns_    = false;

  if (t.shape_.size() != t.strides_.size())
    throw std::runtime_error("Tensor::view: rank de shape e strides diferente");

  t.numel_ = 1;
  for (auto d : t.shape_) t.numel_ *= static_cast<size_t>(d);
  return t;
}

Tensor Tensor::clone() const {
  Tensor out(shape_, dtype_);
  if (numel_ > 0 && data_) {
    std::memcpy(out.data_, data_, nbytes());
  }
  return out;
}

void Tensor::recompute_strides() {
  strides_.resize(shape_.size());
  int64_t acc = 1;
  for (size_t i = shape_.size(); i-- > 0;) {
    strides_[i] = acc;
    acc *= shape_[i];
  }
  numel_ = static_cast<size_t>(acc);
}

void Tensor::allocate() {
  if (numel_ == 0) { data_ = nullptr; return; }
  size_t bytes   = numel_ * dtype_size(dtype_);
  size_t aligned = (bytes + 63) & ~size_t(63);

#if defined(_MSC_VER)
  data_ = _aligned_malloc(aligned, 64);
#else
  if (posix_memalign(&data_, 64, aligned) != 0) data_ = nullptr;
#endif

  if (!data_) throw std::bad_alloc();
  std::memset(data_, 0, bytes);
}

void Tensor::deallocate() {
  if (owns_ && data_) {
#if defined(_MSC_VER)
    _aligned_free(data_);
#else
    std::free(data_);
#endif
  }
  data_ = nullptr;
  owns_ = false;
}

float& Tensor::at(size_t i) {
  if (i >= numel_) throw std::out_of_range("Tensor::at");
  return ptr<float>()[i];
}

float Tensor::at(size_t i) const {
  if (i >= numel_) throw std::out_of_range("Tensor::at");
  return ptr<float>()[i];
}

float& Tensor::at(std::initializer_list<int64_t> idx) {
  if (idx.size() != shape_.size())
    throw std::runtime_error("Tensor::at: rank errado");
  size_t off = 0;
  size_t i = 0;
  for (auto v : idx) {
    off += static_cast<size_t>(v) * static_cast<size_t>(strides_[i++]);
  }
  return ptr<float>()[off];
}

float Tensor::at(std::initializer_list<int64_t> idx) const {
  if (idx.size() != shape_.size())
    throw std::runtime_error("Tensor::at: rank errado");
  size_t off = 0;
  size_t i = 0;
  for (auto v : idx) {
    off += static_cast<size_t>(v) * static_cast<size_t>(strides_[i++]);
  }
  return ptr<float>()[off];
}

void Tensor::fill(float v) {
  if (dtype_ != DType::F32)
    throw std::runtime_error("Tensor::fill: só suporta F32 por ora");
  float* p = ptr<float>();
  for (size_t i = 0; i < numel_; ++i) p[i] = v;
}

float Tensor::min() const {
  const float* p = ptr<float>();
  float m = std::numeric_limits<float>::infinity();
  for (size_t i = 0; i < numel_; ++i) m = std::fmin(m, p[i]);
  return m;
}

float Tensor::max() const {
  const float* p = ptr<float>();
  float m = -std::numeric_limits<float>::infinity();
  for (size_t i = 0; i < numel_; ++i) m = std::fmax(m, p[i]);
  return m;
}

double Tensor::mean() const {
  const float* p = ptr<float>();
  double s = 0.0;
  for (size_t i = 0; i < numel_; ++i) s += p[i];
  return numel_ ? s / static_cast<double>(numel_) : 0.0;
}

double Tensor::l2norm() const {
  const float* p = ptr<float>();
  double s = 0.0;
  for (size_t i = 0; i < numel_; ++i) s += static_cast<double>(p[i]) * p[i];
  return std::sqrt(s);
}

std::string Tensor::repr() const {
  std::ostringstream os;
  os << "Tensor(" << dtype_name(dtype_) << ", [";
  for (size_t i = 0; i < shape_.size(); ++i) {
    os << shape_[i];
    if (i + 1 < shape_.size()) os << ", ";
  }
  os << "], numel=" << numel_ << ", owns=" << (owns_ ? "true" : "false") << ")";
  return os.str();
}

Tensor zeros(std::vector<int64_t> shape, DType dtype) {
  Tensor t(std::move(shape), dtype);
  t.zero();
  return t;
}

Tensor ones(std::vector<int64_t> shape, DType dtype) {
  Tensor t(std::move(shape), dtype);
  t.fill(1.0f);
  return t;
}

Tensor empty(std::vector<int64_t> shape, DType dtype) {
  return Tensor(std::move(shape), dtype);
}

}  // namespace luna::core
