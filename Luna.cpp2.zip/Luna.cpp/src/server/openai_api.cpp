#include "server/openai_api.hpp"

#include <chrono>
#include <cstdio>
#include <sstream>
#include <stdexcept>

namespace luna::server {

namespace {

// ---- Mini JSON ----
// Não usamos lib externa. Parser suficiente para os campos que a API OpenAI
// envia: model, messages[]={role,content}, temperature, top_p, max_tokens,
// stream, stop.

std::string json_escape(const std::string& s) {
  std::string o;
  o.reserve(s.size() + 8);
  for (char c : s) {
    switch (c) {
      case '"':  o += "\\\""; break;
      case '\\': o += "\\\\"; break;
      case '\n': o += "\\n";  break;
      case '\r': o += "\\r";  break;
      case '\t': o += "\\t";  break;
      case '\b': o += "\\b";  break;
      case '\f': o += "\\f";  break;
      default:
        if ((unsigned char)c < 0x20) {
          char buf[8];
          std::snprintf(buf, sizeof(buf), "\\u%04x", (unsigned char)c);
          o += buf;
        } else o += c;
    }
  }
  return o;
}

// Parser simples: navega pelo JSON buscando strings/números por chave.
// Ignora estruturas aninhadas quando não precisa delas.
struct JsonCursor {
  const std::string& s;
  size_t i = 0;

  void skip_ws() { while (i < s.size() && (s[i]==' '||s[i]=='\n'||s[i]=='\r'||s[i]=='\t')) ++i; }
  bool eof() const { return i >= s.size(); }
  char peek() const { return s[i]; }

  bool consume(char c) {
    skip_ws();
    if (i < s.size() && s[i] == c) { ++i; return true; }
    return false;
  }

  std::string parse_string() {
    skip_ws();
    if (i >= s.size() || s[i] != '"') return "";
    ++i;
    std::string out;
    while (i < s.size() && s[i] != '"') {
      char c = s[i++];
      if (c == '\\' && i < s.size()) {
        char n = s[i++];
        switch (n) {
          case 'n': out += '\n'; break;
          case 'r': out += '\r'; break;
          case 't': out += '\t'; break;
          case 'b': out += '\b'; break;
          case 'f': out += '\f'; break;
          case '"': out += '"';  break;
          case '\\': out += '\\'; break;
          case '/': out += '/'; break;
          case 'u': {
            // codepoint \uXXXX — converte básico UTF-8
            if (i + 4 <= s.size()) {
              unsigned cp = 0;
              for (int k = 0; k < 4; ++k) {
                char h = s[i++];
                cp <<= 4;
                if (h >= '0' && h <= '9') cp |= (unsigned)(h - '0');
                else if (h >= 'a' && h <= 'f') cp |= (unsigned)(h - 'a' + 10);
                else if (h >= 'A' && h <= 'F') cp |= (unsigned)(h - 'A' + 10);
              }
              if (cp < 0x80) out += (char)cp;
              else if (cp < 0x800) {
                out += (char)(0xC0 | (cp >> 6));
                out += (char)(0x80 | (cp & 0x3F));
              } else {
                out += (char)(0xE0 | (cp >> 12));
                out += (char)(0x80 | ((cp >> 6) & 0x3F));
                out += (char)(0x80 | (cp & 0x3F));
              }
            }
            break;
          }
          default: out += n;
        }
      } else out += c;
    }
    if (i < s.size() && s[i] == '"') ++i;
    return out;
  }

  double parse_number() {
    skip_ws();
    size_t start = i;
    if (i < s.size() && (s[i] == '-' || s[i] == '+')) ++i;
    while (i < s.size() && ((s[i] >= '0' && s[i] <= '9') || s[i] == '.' ||
                            s[i] == 'e' || s[i] == 'E' || s[i] == '-' || s[i] == '+'))
      ++i;
    if (i == start) return 0.0;
    try { return std::stod(s.substr(start, i - start)); }
    catch (...) { return 0.0; }
  }

  bool parse_bool() {
    skip_ws();
    if (s.compare(i, 4, "true") == 0) { i += 4; return true; }
    if (s.compare(i, 5, "false") == 0) { i += 5; return false; }
    return false;
  }

  // Pula valor JSON (string, número, objeto, array, bool, null)
  void skip_value() {
    skip_ws();
    if (eof()) return;
    char c = s[i];
    if (c == '"') { parse_string(); return; }
    if (c == '{' || c == '[') {
      char open = c, close = (c == '{') ? '}' : ']';
      int depth = 0;
      while (i < s.size()) {
        if (s[i] == '"') { parse_string(); continue; }
        if (s[i] == open) ++depth;
        else if (s[i] == close) {
          --depth; ++i;
          if (depth == 0) return;
          continue;
        }
        ++i;
      }
      return;
    }
    if (s.compare(i, 4, "true") == 0) { i += 4; return; }
    if (s.compare(i, 5, "false") == 0) { i += 5; return; }
    if (s.compare(i, 4, "null") == 0) { i += 4; return; }
    parse_number();
  }
};

struct ChatMessage { std::string role; std::string content; };

struct ChatRequest {
  std::string model;
  std::vector<ChatMessage> messages;
  float temp = -1;
  int   top_k = -1;
  float top_p = -1;
  int   max_tokens = -1;
  bool  stream = false;
};

ChatRequest parse_chat_request(const std::string& body) {
  ChatRequest r;
  JsonCursor c{body};

  if (!c.consume('{')) return r;

  while (!c.eof()) {
    c.skip_ws();
    if (c.consume('}')) break;
    if (c.eof()) break;

    std::string key = c.parse_string();
    c.skip_ws();
    if (!c.consume(':')) break;

    if (key == "model") {
      r.model = c.parse_string();
    } else if (key == "temperature") {
      r.temp = (float)c.parse_number();
    } else if (key == "top_p") {
      r.top_p = (float)c.parse_number();
    } else if (key == "top_k") {
      r.top_k = (int)c.parse_number();
    } else if (key == "max_tokens") {
      r.max_tokens = (int)c.parse_number();
    } else if (key == "stream") {
      r.stream = c.parse_bool();
    } else if (key == "messages") {
      c.skip_ws();
      if (!c.consume('[')) { c.skip_value(); continue; }
      while (!c.eof()) {
        c.skip_ws();
        if (c.consume(']')) break;
        if (!c.consume('{')) { c.skip_value(); continue; }
        ChatMessage m;
        while (!c.eof()) {
          c.skip_ws();
          if (c.consume('}')) break;
          std::string k2 = c.parse_string();
          c.skip_ws();
          if (!c.consume(':')) break;
          if (k2 == "role") m.role = c.parse_string();
          else if (k2 == "content") m.content = c.parse_string();
          else c.skip_value();
          c.skip_ws();
          c.consume(',');
        }
        r.messages.push_back(std::move(m));
        c.skip_ws();
        c.consume(',');
      }
    } else {
      c.skip_value();
    }
    c.skip_ws();
    c.consume(',');
  }
  return r;
}


[[maybe_unused]] std::string now_iso8601_placeholder();
std::string gen_id() {
  static std::atomic<uint64_t> counter{0};
  char buf[64];
  std::snprintf(buf, sizeof(buf), "chatcmpl-luna-%llu",
                (unsigned long long)counter.fetch_add(1));
  return buf;
}

}  // namespace

bool OpenAiApi::load(const ServerConfig& cfg) {
  cfg_ = cfg;
  if (!file_.open(cfg_.model_path)) {
    std::fprintf(stderr, "server: não abri %s\n", cfg_.model_path.c_str());
    return false;
  }
  if (!tk_.load(file_)) {
    std::fprintf(stderr, "server: tokenizer falhou\n");
    return false;
  }
  ct_.detect(file_);
  std::printf("[server] formato chat: %s\n",
              tokenizer::chat_format_name(ct_.format));

  if (!w_.load(file_)) {
    std::fprintf(stderr, "server: pesos falharam\n");
    return false;
  }
  ctx_size_ = cfg_.n_ctx;
  if (w_.config.n_ctx_train > 0)
    ctx_size_ = std::min(ctx_size_, w_.config.n_ctx_train);
  fwd_ = std::make_unique<models::LlamaForward>(w_, ctx_size_);
  stops_ = ct_.stop_ids(tk_);

  // Se o GGUF tem um nome próprio, usa como id
  auto it = file_.metadata.find("general.name");
  if (it != file_.metadata.end()) {
    if (auto* s = std::get_if<std::string>(&it->second)) {
      if (!s->empty()) cfg_.model_id = *s;
    }
  }
  return true;
}

std::string OpenAiApi::handle_models() {
  std::ostringstream os;
  os << "{\"object\":\"list\",\"data\":[{"
     << "\"id\":\"" << json_escape(cfg_.model_id) << "\","
     << "\"object\":\"model\","
     << "\"created\":" << (long)std::time(nullptr) << ","
     << "\"owned_by\":\"luna.cpp\""
     << "}]}";
  return os.str();
}

void OpenAiApi::generate(const std::vector<int32_t>& prompt_ids,
                         const models::SampleOpts& opts,
                         std::function<void(const std::string&)> write_fn,
                         std::function<bool()> stop_early) {
  std::lock_guard<std::mutex> lk(mu_);

  fwd_->reset();
  std::vector<int32_t> ctx;
  ctx.reserve(prompt_ids.size() + 64);

  auto logits = [&]{
    std::vector<float> out;
    for (size_t i = 0; i < prompt_ids.size(); ++i) {
      int32_t pos = (int32_t)ctx.size();
      if (pos >= ctx_size_) break;
      out = fwd_->forward_token(prompt_ids[i], pos);
      ctx.push_back(prompt_ids[i]);
    }
    return out;
  }();
  if (logits.empty()) return;

  uint64_t rng = 0xDEADBEEFCAFEBABEULL;

  for (int step = 0; step < cfg_.max_gen; ++step) {
    if (stop_early && stop_early()) break;
    int32_t next = models::sample(logits, ctx, opts, rng);

    bool is_stop = false;
    for (auto s : stops_) if (s == next) { is_stop = true; break; }
    if (is_stop) break;

    std::string piece = tk_.decode_one(next);
    if (!piece.empty()) write_fn(piece);

    ctx.push_back(next);
    int32_t pos = (int32_t)ctx.size() - 1;
    if (pos + 1 >= ctx_size_) break;
    logits = fwd_->forward_token(next, pos);
  }
}

std::string OpenAiApi::handle_chat_completions(const std::string& body,
                                               bool /*stream*/) {
  auto req = parse_chat_request(body);

  models::SampleOpts opts;
  opts.temp           = req.temp  > 0 ? req.temp  : cfg_.temp;
  opts.top_k          = req.top_k > 0 ? req.top_k : cfg_.top_k;
  opts.top_p          = req.top_p > 0 ? req.top_p : cfg_.top_p;
  opts.repeat_penalty = cfg_.repeat_penalty;
  opts.repeat_last_n  = cfg_.repeat_last_n;

  // Concatena histórico. Usa system do primeiro, depois user/assistant.
  std::string system = cfg_.system;
  std::vector<ChatMessage> turns;
  for (auto& m : req.messages) {
    if (m.role == "system") system = m.content;
    else turns.push_back(m);
  }

  // Constrói prompt:
  //   - Se 1º turno, build_prompt(system, user1)
  //   - Senão, concatena turnos como texto simples (histórico resumido)
  std::vector<int32_t> prompt;
  if (turns.empty()) {
    prompt = ct_.build_prompt(tk_, system, "");
  } else {
    prompt = ct_.build_prompt(tk_, system, turns[0].content);
    for (size_t i = 1; i + 0 < turns.size(); ++i) {
      if (turns[i].role == "assistant") {
        // adiciona a resposta anterior do assistente como contexto
        auto a = tk_.encode(turns[i].content, /*add_bos=*/false);
        prompt.insert(prompt.end(), a.begin(), a.end());
        // fecha o turno do assistente
        for (auto s : stops_) prompt.push_back(s);
        if (i + 1 < turns.size()) {
          auto nx = ct_.next_turn(tk_, turns[i + 1].content);
          prompt.insert(prompt.end(), nx.begin(), nx.end());
        }
      }
    }
  }

  std::string content;
  int n_generated = 0;
  generate(prompt, opts, [&](const std::string& s){ content += s; ++n_generated; });

  // Monta a resposta OpenAI
  std::ostringstream os;
  os << "{"
     << "\"id\":\"" << gen_id() << "\","
     << "\"object\":\"chat.completion\","
     << "\"created\":" << (long)std::time(nullptr) << ","
     << "\"model\":\"" << json_escape(cfg_.model_id) << "\","
     << "\"choices\":[{"
     <<   "\"index\":0,"
     <<   "\"message\":{\"role\":\"assistant\","
     <<     "\"content\":\"" << json_escape(content) << "\"},"
     <<   "\"finish_reason\":\"stop\""
     << "}],"
     << "\"usage\":{\"prompt_tokens\":" << (int)prompt.size()
     <<          ",\"completion_tokens\":" << n_generated
     <<          ",\"total_tokens\":" << ((int)prompt.size() + n_generated) << "}"
     << "}";
  return os.str();
}

void OpenAiApi::handle_chat_stream(const std::string& body,
                                   std::function<void(const std::string&)> write) {
  auto req = parse_chat_request(body);

  models::SampleOpts opts;
  opts.temp           = req.temp  > 0 ? req.temp  : cfg_.temp;
  opts.top_k          = req.top_k > 0 ? req.top_k : cfg_.top_k;
  opts.top_p          = req.top_p > 0 ? req.top_p : cfg_.top_p;
  opts.repeat_penalty = cfg_.repeat_penalty;
  opts.repeat_last_n  = cfg_.repeat_last_n;

  std::string system = cfg_.system;
  std::vector<ChatMessage> turns;
  for (auto& m : req.messages) {
    if (m.role == "system") system = m.content;
    else turns.push_back(m);
  }

  std::vector<int32_t> prompt;
  if (turns.empty()) prompt = ct_.build_prompt(tk_, system, "");
  else {
    prompt = ct_.build_prompt(tk_, system, turns[0].content);
    for (size_t i = 1; i < turns.size(); ++i) {
      if (turns[i].role == "assistant") {
        auto a = tk_.encode(turns[i].content, false);
        prompt.insert(prompt.end(), a.begin(), a.end());
        for (auto s : stops_) prompt.push_back(s);
        if (i + 1 < turns.size()) {
          auto nx = ct_.next_turn(tk_, turns[i + 1].content);
          prompt.insert(prompt.end(), nx.begin(), nx.end());
        }
      }
    }
  }

  const std::string id = gen_id();
  const long created = (long)std::time(nullptr);
  const std::string model_id = cfg_.model_id;

  auto send_delta = [&](const std::string& text) {
    std::ostringstream os;
    os << "data: {"
       << "\"id\":\"" << id << "\","
       << "\"object\":\"chat.completion.chunk\","
       << "\"created\":" << created << ","
       << "\"model\":\"" << json_escape(model_id) << "\","
       << "\"choices\":[{"
       <<   "\"index\":0,"
       <<   "\"delta\":{\"content\":\"" << json_escape(text) << "\"},"
       <<   "\"finish_reason\":null"
       << "}]}\n\n";
    write(os.str());
  };

  // Chunk inicial com role
  {
    std::ostringstream os;
    os << "data: {"
       << "\"id\":\"" << id << "\","
       << "\"object\":\"chat.completion.chunk\","
       << "\"created\":" << created << ","
       << "\"model\":\"" << json_escape(model_id) << "\","
       << "\"choices\":[{"
       <<   "\"index\":0,"
       <<   "\"delta\":{\"role\":\"assistant\"},"
       <<   "\"finish_reason\":null"
       << "}]}\n\n";
    write(os.str());
  }

  generate(prompt, opts, send_delta);

  // Chunk final
  {
    std::ostringstream os;
    os << "data: {"
       << "\"id\":\"" << id << "\","
       << "\"object\":\"chat.completion.chunk\","
       << "\"created\":" << created << ","
       << "\"model\":\"" << json_escape(model_id) << "\","
       << "\"choices\":[{"
       <<   "\"index\":0,"
       <<   "\"delta\":{},"
       <<   "\"finish_reason\":\"stop\""
       << "}]}\n\n";
    write(os.str());
  }

  write("data: [DONE]\n\n");
}

std::string OpenAiApi::handle_completions(const std::string& body) {
  // Implementação mínima: aceita {prompt, max_tokens, temperature, ...}
  JsonCursor c{body};
  std::string prompt_text;
  float temp = cfg_.temp;
  int max_tokens = cfg_.max_gen;

  if (c.consume('{')) {
    while (!c.eof()) {
      c.skip_ws();
      if (c.consume('}')) break;
      std::string k = c.parse_string();
      c.skip_ws();
      if (!c.consume(':')) break;
      if (k == "prompt") prompt_text = c.parse_string();
      else if (k == "temperature") temp = (float)c.parse_number();
      else if (k == "max_tokens") max_tokens = (int)c.parse_number();
      else c.skip_value();
      c.skip_ws(); c.consume(',');
    }
  }

  models::SampleOpts opts;
  opts.temp = temp;
  opts.top_k = cfg_.top_k;
  opts.top_p = cfg_.top_p;
  opts.repeat_penalty = cfg_.repeat_penalty;
  opts.repeat_last_n = cfg_.repeat_last_n;

  auto ids = tk_.encode(prompt_text);
  std::string content;
  (void)max_tokens;
  generate(ids, opts, [&](const std::string& s){ content += s; });

  std::ostringstream os;
  os << "{"
     << "\"id\":\"" << gen_id() << "\","
     << "\"object\":\"text_completion\","
     << "\"created\":" << (long)std::time(nullptr) << ","
     << "\"model\":\"" << json_escape(cfg_.model_id) << "\","
     << "\"choices\":[{"
     <<   "\"text\":\"" << json_escape(content) << "\","
     <<   "\"index\":0,"
     <<   "\"finish_reason\":\"stop\""
     << "}]}";
  return os.str();
}

}  // namespace luna::server
