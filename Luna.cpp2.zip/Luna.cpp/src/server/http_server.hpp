#pragma once

#include <atomic>
#include <functional>
#include <map>
#include <string>
#include <thread>
#include <vector>

namespace luna::server {

struct HttpRequest {
  std::string method;
  std::string path;
  std::string query;
  std::map<std::string, std::string> headers;
  std::string body;
};

struct HttpResponse {
  int status = 200;
  std::string content_type = "application/json";
  std::map<std::string, std::string> extra_headers;
  std::string body;
  bool close = false;
};

using Handler = std::function<HttpResponse(const HttpRequest&)>;
// Handler para streaming SSE: recebe um callback de write
using StreamHandler = std::function<void(const HttpRequest&,
                                         std::function<void(const std::string&)>)>;

class HttpServer {
 public:
  HttpServer(int port = 8080);
  ~HttpServer();

  void route(const std::string& method, const std::string& path, Handler h);
  void route_stream(const std::string& method, const std::string& path, StreamHandler h);

  bool start();     // começa a escutar (bloqueante: rode em thread própria)
  void stop();

  int port() const { return port_; }

 private:
  struct Route { std::string method; std::string path; Handler h; };
  struct StreamRoute { std::string method; std::string path; StreamHandler h; };

  void accept_loop();
  void handle_client(int fd);

  int port_;
  int listen_fd_ = -1;
  std::atomic<bool> running_{false};
  std::vector<Route> routes_;
  std::vector<StreamRoute> stream_routes_;
};

}  // namespace luna::server
