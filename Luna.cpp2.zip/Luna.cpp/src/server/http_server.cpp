#include "server/http_server.hpp"

#include <arpa/inet.h>
#include <cstring>
#include <netinet/in.h>
#include <sstream>
#include <stdexcept>
#include <sys/select.h>
#include <sys/socket.h>
#include <unistd.h>
#include <ctime>

#include <cstdio>

namespace luna::server {

HttpServer::HttpServer(int port) : port_(port) {}

HttpServer::~HttpServer() { stop(); }

void HttpServer::route(const std::string& method,
                       const std::string& path, Handler h) {
  routes_.push_back({method, path, std::move(h)});
}

void HttpServer::route_stream(const std::string& method,
                              const std::string& path, StreamHandler h) {
  stream_routes_.push_back({method, path, std::move(h)});
}

bool HttpServer::start() {
  listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
  if (listen_fd_ < 0) return false;

  int opt = 1;
  setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

  sockaddr_in addr{};
  addr.sin_family = AF_INET;
  addr.sin_addr.s_addr = htonl(INADDR_ANY);
  addr.sin_port = htons((uint16_t)port_);

  if (bind(listen_fd_, (sockaddr*)&addr, sizeof(addr)) < 0) {
    std::fprintf(stderr, "bind falhou na porta %d\n", port_);
    close(listen_fd_);
    listen_fd_ = -1;
    return false;
  }
  if (listen(listen_fd_, 64) < 0) {
    close(listen_fd_);
    listen_fd_ = -1;
    return false;
  }

  running_ = true;
  accept_loop();
  return true;
}

void HttpServer::stop() {
  running_ = false;
  // Não fechamos o fd aqui: o accept_loop detecta running_=false
  // no timeout do select e sai por conta própria.
}

namespace {

std::string read_line(int fd, std::string& buf) {
  for (;;) {
    auto pos = buf.find("\r\n");
    if (pos != std::string::npos) {
      std::string line = buf.substr(0, pos);
      buf.erase(0, pos + 2);
      return line;
    }
    char tmp[4096];
    ssize_t n = recv(fd, tmp, sizeof(tmp), 0);
    if (n <= 0) return "";
    buf.append(tmp, (size_t)n);
  }
}

void write_all(int fd, const std::string& s) {
  size_t off = 0;
  while (off < s.size()) {
    ssize_t n = send(fd, s.data() + off, s.size() - off, MSG_NOSIGNAL);
    if (n <= 0) return;
    off += (size_t)n;
  }
}

std::string status_text(int code) {
  switch (code) {
    case 200: return "OK";
    case 400: return "Bad Request";
    case 404: return "Not Found";
    case 405: return "Method Not Allowed";
    case 500: return "Internal Server Error";
    default:  return "OK";
  }
}

}  // namespace

void HttpServer::accept_loop() {
  while (running_) {
    // select() com timeout: acorda a cada 200ms para checar running_
    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(listen_fd_, &rfds);
    timeval tv{0, 200000};   // 200 ms

    int sel = select(listen_fd_ + 1, &rfds, nullptr, nullptr, &tv);
    if (!running_) break;
    if (sel < 0) {
      // interrompido por signal — só verifica a flag e continua
      continue;
    }
    if (sel == 0) continue;   // timeout

    sockaddr_in cli{};
    socklen_t len = sizeof(cli);
    int fd = accept(listen_fd_, (sockaddr*)&cli, &len);
    if (fd < 0) {
      if (!running_) break;
      continue;
    }
    std::thread([this, fd]{ handle_client(fd); close(fd); }).detach();
  }

  // Agora sim fecha o listen socket (threads de cliente continuam ativas
  // mas o processo pode ser terminado depois)
  if (listen_fd_ >= 0) {
    close(listen_fd_);
    listen_fd_ = -1;
  }
}

void HttpServer::handle_client(int fd) {
  std::string buf;
  std::string req_line = read_line(fd, buf);
  if (req_line.empty()) return;

  HttpRequest req;
  {
    std::istringstream iss(req_line);
    std::string target;
    iss >> req.method >> target;
    auto q = target.find('?');
    if (q == std::string::npos) {
      req.path = target;
    } else {
      req.path = target.substr(0, q);
      req.query = target.substr(q + 1);
    }
  }

  for (;;) {
    std::string line = read_line(fd, buf);
    if (line.empty()) break;
    auto colon = line.find(':');
    if (colon == std::string::npos) continue;
    std::string k = line.substr(0, colon);
    std::string v = line.substr(colon + 1);
    while (!v.empty() && (v[0] == ' ' || v[0] == '\t')) v.erase(0, 1);
    for (auto& c : k) c = (char)std::tolower((unsigned char)c);
    req.headers[k] = v;
  }

  size_t content_length = 0;
  if (auto it = req.headers.find("content-length"); it != req.headers.end())
    content_length = (size_t)std::stoul(it->second);

  while (buf.size() < content_length) {
    char tmp[8192];
    ssize_t n = recv(fd, tmp, sizeof(tmp), 0);
    if (n <= 0) break;
    buf.append(tmp, (size_t)n);
  }
  req.body = buf.substr(0, content_length);

  for (auto& sr : stream_routes_) {
    if (sr.method == req.method && sr.path == req.path) {
      write_all(fd, "HTTP/1.1 200 OK\r\n"
                    "Content-Type: text/event-stream\r\n"
                    "Cache-Control: no-cache\r\n"
                    "Connection: close\r\n\r\n");
      auto send_chunk = [fd](const std::string& s){ write_all(fd, s); };
      try { sr.h(req, send_chunk); }
      catch (const std::exception& e) {
        std::string err = std::string("data: {\"error\":\"") + e.what() + "\"}\n\n";
        send_chunk(err);
      }
      return;
    }
  }

  for (auto& r : routes_) {
    if (r.method == req.method && r.path == req.path) {
      HttpResponse resp;
      try { resp = r.h(req); }
      catch (const std::exception& e) {
        resp.status = 500;
        resp.body = std::string("{\"error\":\"") + e.what() + "\"}";
      }
      std::string head = "HTTP/1.1 " + std::to_string(resp.status) + " " +
                         status_text(resp.status) + "\r\n" +
                         "Content-Type: " + resp.content_type + "\r\n" +
                         "Content-Length: " + std::to_string(resp.body.size()) + "\r\n" +
                         "Connection: close\r\n";
      for (auto& [k, v] : resp.extra_headers)
        head += k + ": " + v + "\r\n";
      head += "\r\n";
      write_all(fd, head);
      write_all(fd, resp.body);
      return;
    }
  }

  std::string body = "{\"error\":\"not found\"}";
  std::string resp = "HTTP/1.1 404 Not Found\r\n"
                     "Content-Type: application/json\r\n"
                     "Content-Length: " + std::to_string(body.size()) + "\r\n"
                     "Connection: close\r\n\r\n" + body;
  write_all(fd, resp);
}

}  // namespace luna::server
