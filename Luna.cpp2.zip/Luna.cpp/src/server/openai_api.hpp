#pragma once

#include "models/forward.hpp"
#include "models/llama_weights.hpp"
#include "tokenizer/bpe.hpp"
#include "tokenizer/chat.hpp"
#include <atomic>
#include <memory>
#include <mutex>
#include <string>

namespace luna::server {

struct ServerConfig {
  std::string model_path;
  std::string model_id   = "luna";
  std::string system     = "You are a helpful AI assistant.";
  int   n_ctx            = 2048;
  int   max_gen          = 512;
  float temp             = 0.7f;
  int   top_k            = 40;
  float top_p            = 0.9f;
  float repeat_penalty   = 1.15f;
  int   repeat_last_n    = 64;
};

class OpenAiApi {
 public:
  bool load(const ServerConfig& cfg);

  // Endpoints (devolvem o corpo JSON)
  std::string handle_models();
  std::string handle_chat_completions(const std::string& body,
                                      bool stream);
  void handle_chat_stream(const std::string& body,
                          std::function<void(const std::string&)> write);

  // Para /v1/completions (texto puro, não-chat)
  std::string handle_completions(const std::string& body);

  const ServerConfig& config() const { return cfg_; }

 private:
  ServerConfig cfg_;
  io::GgufFile file_;
  tokenizer::BpeTokenizer tk_;
  tokenizer::ChatTemplate ct_;
  models::LlamaWeights w_;

  // Uma única instância de forward (cache KV compartilhado) com lock.
  std::unique_ptr<models::LlamaForward> fwd_;
  std::mutex mu_;

  int ctx_size_ = 2048;
  std::vector<int32_t> stops_;

  // Gera tokens. write_fn recebe cada pedaço de texto.
  // stop_early pode ser consultado para abortar (stream cancelado).
  void generate(const std::vector<int32_t>& prompt_ids,
                const models::SampleOpts& opts,
                std::function<void(const std::string&)> write_fn,
                std::function<bool()> stop_early = nullptr);
};

}  // namespace luna::server
