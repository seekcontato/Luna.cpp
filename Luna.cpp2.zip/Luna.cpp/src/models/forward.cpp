#include "models/forward.hpp"
#include "core/threadpool.hpp"
#include "io/gguf.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <stdexcept>

#if defined(__ARM_NEON) || defined(__ARM_NEON__)
  #include <arm_neon.h>
  #define LUNA_HAVE_NEON 1
#else
  #define LUNA_HAVE_NEON 0
#endif

namespace luna::models {

namespace {

const std::array<float, 65536>& fp16_lut() {
  static const std::array<float, 65536> t = []{
    std::array<float, 65536> lut{};
    for (uint32_t h = 0; h < 65536; ++h)
      lut[h] = io::fp16_to_fp32((uint16_t)h);
    return lut;
  }();
  return t;
}

#if LUNA_HAVE_NEON
void linear_f16_neon(const float* x, const uint16_t* W, float* y,
                     int n_in, int n_out) {
  for (int j = 0; j < n_out; ++j) {
    const uint16_t* wj = W + (size_t)j * n_in;
    float32x4_t acc0 = vdupq_n_f32(0.0f);
    float32x4_t acc1 = vdupq_n_f32(0.0f);
    int i = 0;
    for (; i + 8 <= n_in; i += 8) {
      uint16x8_t h8 = vld1q_u16(wj + i);
      float32x4_t f_lo = vcvt_f32_f16(vget_low_f16 (vreinterpretq_f16_u16(h8)));
      float32x4_t f_hi = vcvt_f32_f16(vget_high_f16(vreinterpretq_f16_u16(h8)));
      float32x4_t x_lo = vld1q_f32(x + i);
      float32x4_t x_hi = vld1q_f32(x + i + 4);
      acc0 = vfmaq_f32(acc0, x_lo, f_lo);
      acc1 = vfmaq_f32(acc1, x_hi, f_hi);
    }
    for (; i + 4 <= n_in; i += 4) {
      uint16x4_t h4 = vld1_u16(wj + i);
      float32x4_t f4 = vcvt_f32_f16(vreinterpret_f16_u16(h4));
      float32x4_t xv = vld1q_f32(x + i);
      acc0 = vfmaq_f32(acc0, xv, f4);
    }
    float sum = vaddvq_f32(acc0) + vaddvq_f32(acc1);
    for (; i < n_in; ++i) sum += x[i] * io::fp16_to_fp32(wj[i]);
    y[j] = sum;
  }
}
#endif

[[maybe_unused]] void linear_f16_lut(const float* x, const uint16_t* W, float* y,
                                     int n_in, int n_out) {
  const float* LUT = fp16_lut().data();
  for (int j = 0; j < n_out; ++j) {
    const uint16_t* wj = W + (size_t)j * n_in;
    float acc = 0.0f;
    for (int i = 0; i < n_in; ++i) acc += x[i] * LUT[wj[i]];
    y[j] = acc;
  }
}

void linear_f16_worker(const float* x, const uint16_t* W, float* y,
                       int n_in, int lo, int hi) {
#if LUNA_HAVE_NEON
  linear_f16_neon(x, W + (size_t)lo * n_in, y + lo, n_in, hi - lo);
#else
  linear_f16_lut(x, W + (size_t)lo * n_in, y + lo, n_in, hi - lo);
#endif
}

void linear_f16(const float* x, const uint16_t* W, float* y, int n_in, int n_out) {
  if (n_out < 64) { linear_f16_worker(x, W, y, n_in, 0, n_out); return; }
  auto& pool = core::ThreadPool::instance();
  const int nt = pool.n_threads();
  const int chunk = (n_out + nt - 1) / nt;
  pool.parallel_for(nt, [&](int t){
    int lo = t * chunk;
    int hi = std::min(lo + chunk, n_out);
    if (lo < hi) linear_f16_worker(x, W, y, n_in, lo, hi);
  });
}

// Bytes por linha de W (W é [n_in, n_out], cada linha tem n_in valores)
size_t bytes_per_row(io::GgmlType type, int64_t n_in) {
  if (type == io::GgmlType::F16) return (size_t)n_in * 2;
  if (type == io::GgmlType::F32) return (size_t)n_in * 4;
  const size_t bs = io::ggml_block_size(type);
  const size_t ts = io::ggml_type_size(type);
  // GGUF pode arredondar para múltiplo do block (padding no final da linha)
  const size_t nb = (size_t)((n_in + (int64_t)bs - 1) / (int64_t)bs);
  return nb * ts;
}

void dequant_row(io::GgmlType type, const uint8_t* src, float* dst, int64_t n) {
  if (type == io::GgmlType::F16) {
    const uint16_t* u = reinterpret_cast<const uint16_t*>(src);
    for (int64_t i = 0; i < n; ++i) dst[i] = io::fp16_to_fp32(u[i]);
  } else {
    io::luna_dq_dispatch(type, src, dst, (size_t)n);
  }
}

void linear_qt(const float* x, const QuantTensor& W, float* y,
               int n_in, int n_out) {
  if (W.empty()) throw std::runtime_error("linear_qt: tensor vazio");

  // Fast path: F16 puro -> NEON direto
  if (W.is_f16()) {
    linear_f16(x, reinterpret_cast<const uint16_t*>(W.data.data()),
               y, n_in, n_out);
    return;
  }

  const size_t bpr = bytes_per_row(W.type, n_in);

  auto worker = [&](int lo, int hi) {
    // thread_local POR THREAD que executa o worker (a antiga versão
    // inicializava só na main thread, deixando as threads do pool com
    // buffer vazio -> segfault)
    thread_local std::vector<float> tls;
    if ((int)tls.size() < n_in) tls.resize(n_in);

    for (int j = lo; j < hi; ++j) {
      const uint8_t* src = W.data.data() + (size_t)j * bpr;
      dequant_row(W.type, src, tls.data(), n_in);
      float acc = 0.0f;
      for (int i = 0; i < n_in; ++i) acc += x[i] * tls[i];
      y[j] = acc;
    }
  };

  if (n_out < 64) { worker(0, n_out); return; }
  auto& pool = core::ThreadPool::instance();
  const int nt = pool.n_threads();
  const int chunk = (n_out + nt - 1) / nt;
  pool.parallel_for(nt, [&](int t){
    int lo = t * chunk;
    int hi = std::min(lo + chunk, n_out);
    if (lo < hi) worker(lo, hi);
  });
}

void add_bias(float* y, const std::vector<float>& b, int n) {
  if (b.empty()) return;
  for (int i = 0; i < n; ++i) y[i] += b[i];
}

void rmsnorm_vec(const float* x, const float* w, float* y, int n, float eps) {
  float ss = 0.0f;
  for (int i = 0; i < n; ++i) ss += x[i] * x[i];
  ss = ss / (float)n + eps;
  const float inv = 1.0f / std::sqrt(ss);
  for (int i = 0; i < n; ++i) y[i] = x[i] * inv * w[i];
}

// QK norm: RMS norm per-head sobre head_dim
void qk_norm_apply(float* x, int n_heads, int hd, const float* w, float eps) {
  for (int h = 0; h < n_heads; ++h) {
    float* p = x + (size_t)h * hd;
    float ss = 0.0f;
    for (int d = 0; d < hd; ++d) ss += p[d] * p[d];
    ss = ss / (float)hd + eps;
    const float inv = 1.0f / std::sqrt(ss);
    for (int d = 0; d < hd; ++d) p[d] = p[d] * inv * w[d];
  }
}

void rope_vec(float* x, int n_heads, int head_dim, int pos, float theta) {
  const int half = head_dim / 2;
  for (int h = 0; h < n_heads; ++h) {
    float* head = x + (size_t)h * head_dim;
    for (int i = 0; i < half; ++i) {
      const float freq = 1.0f / std::pow(theta, (float)(2*i)/(float)head_dim);
      const float angle = (float)pos * freq;
      const float c = std::cos(angle), s = std::sin(angle);
      const float x0 = head[i], x1 = head[i+half];
      head[i] = x0*c - x1*s;
      head[i+half] = x0*s + x1*c;
    }
  }
}

// LFM2 shortconv: Conv1D causal + gating
// x: [n_embd], state: [(K-1)*n_embd], W: ShortConvWeights
// out: [n_embd] (com residual aplicado fora)
void shortconv_op(const float* x,
                  const ShortConvWeights& W,
                  float* state, int n_embd, int K, int n_embd_proj,
                  float* out, float* scratch) {
  // 1. BCx = in_proj @ x  →  [3*n_embd_proj] (n_embd_proj = 1024, 3x = 3072)
  // Reaproveita dequant_row para lidar com Q4_K
  const size_t bpr = bytes_per_row(W.in_proj.type, n_embd);
  const int nout = (int)W.in_proj.n_out;   // = 3*n_embd
  for (int j = 0; j < nout; ++j) {
    const uint8_t* src = W.in_proj.data.data() + (size_t)j * bpr;
    // dequantiza a linha (n_embd floats) e faz dot com x
    thread_local std::vector<float> row;
    if ((int)row.size() < n_embd) row.resize(n_embd);
    dequant_row(W.in_proj.type, src, row.data(), n_embd);
    float acc = 0.0f;
    for (int i = 0; i < n_embd; ++i) acc += x[i] * row[i];
    scratch[j] = acc;
  }

  float* B  = scratch;
  float* C  = scratch + n_embd;
  float* xg = scratch + 2 * n_embd;

  // 2. Bx = B * x_  (gate multiplicativo simples, SEM sigmoid)
  thread_local std::vector<float> Bx;
  if ((int)Bx.size() < n_embd) Bx.resize(n_embd);
  for (int i = 0; i < n_embd; ++i) Bx[i] = B[i] * xg[i];

  // 3. Conv1D causal em Bx
  //    Estado: [Bx[t-K+1], ..., Bx[t-1]]
  //    Layout GGUF [K, n_embd] column-major: W.conv[c*K + k]
  for (int i = 0; i < n_embd; ++i) out[i] = 0.0f;
  for (int k = 0; k < K - 1; ++k) {
    const float* sk = state + (size_t)k * n_embd;
    for (int i = 0; i < n_embd; ++i)
      out[i] += W.conv[(size_t)i * K + k] * sk[i];
  }
  {
    const int k = K - 1;
    for (int i = 0; i < n_embd; ++i)
      out[i] += W.conv[(size_t)i * K + k] * Bx[i];
  }

  // 4. State update: shift, insere Bx no fim
  for (int k = 0; k < K - 2; ++k)
    std::memcpy(state + (size_t)k * n_embd,
                state + (size_t)(k+1) * n_embd,
                n_embd * sizeof(float));
  std::memcpy(state + (size_t)(K-2) * n_embd, Bx.data(),
              n_embd * sizeof(float));

  // 5. Gate final: out *= C
  for (int i = 0; i < n_embd; ++i) out[i] *= C[i];
}

inline float gelu_tanh(float x) {
  // Aproximação tanh (igual PyTorch gelu_pytorch_tanh)
  const float c = 0.7978845608028654f;   // sqrt(2/pi)
  const float k = 0.044715f;
  return 0.5f * x * (1.0f + std::tanh(c * (x + k * x*x*x)));
}

}  // namespace

LlamaForward::LlamaForward(const LlamaWeights& w, int32_t n_ctx)
    : w_(w), n_ctx_(n_ctx) {
  cache_.resize(w_.layers.size());
  for (auto& c : cache_) {
    c.k.assign((size_t)n_ctx_ * w_.n_embd_kv, 0.0f);
    c.v.assign((size_t)n_ctx_ * w_.n_embd_v,  0.0f);
  }
  // LFM2: inicializa buffer de conv (kernel-1 = 2 posições)
  conv_cache_.resize(w_.layers.size());
  const int K = w_.config.conv_kernel;
  if (K > 1) {
    for (size_t i = 0; i < conv_cache_.size(); ++i) {
      if (w_.layers[i].shortconv.present)
        conv_cache_[i].buf.assign((size_t)(K - 1) * w_.config.n_embd, 0.0f);
    }
  }
}

void LlamaForward::reset() {
  for (auto& c : cache_) {
    std::fill(c.k.begin(), c.k.end(), 0.0f);
    std::fill(c.v.begin(), c.v.end(), 0.0f);
  }
  for (auto& c : conv_cache_) {
    std::fill(c.buf.begin(), c.buf.end(), 0.0f);
  }
}

std::vector<float> LlamaForward::forward_token(int32_t token, int32_t pos) {
  const auto& C = w_.config;
  const int n_embd    = C.n_embd;
  const int n_head    = C.n_head;
  const int n_head_kv = C.n_head_kv;
  const int hd_k      = w_.head_dim_k;
  const int hd_v      = w_.head_dim_v;
  const int n_embd_q  = w_.n_embd_q;
  const int n_embd_kv = w_.n_embd_kv;
  const int n_embd_v  = w_.n_embd_v;
  const int n_ff      = C.n_ff;
  const int n_vocab   = C.n_vocab;
  const float eps     = C.rms_eps;
  const float theta   = C.rope_theta;

  if (token < 0 || token >= n_vocab) throw std::runtime_error("token fora do vocab");
  if (pos < 0 || pos >= n_ctx_) throw std::runtime_error("pos >= n_ctx");

  std::vector<float> x(n_embd), xn(n_embd);
  std::vector<float> q(n_embd_q), k(n_embd_kv), v(n_embd_v);
  std::vector<float> attn_out(n_embd_q), attn_proj(n_embd);
  std::vector<float> gate(n_ff), up(n_ff), ffn_out(n_embd);
  std::vector<float> scores(pos + 1);

  {
    const size_t bpr = bytes_per_row(w_.token_embd.type, n_embd);
    const uint8_t* src = w_.token_embd.data.data() + (size_t)token * bpr;
    dequant_row(w_.token_embd.type, src, x.data(), n_embd);
    for (int i = 0; i < n_embd; ++i) x[i] *= C.embd_scale;
  }

  const int group = n_head / n_head_kv;
  const float scale = 1.0f / std::sqrt((float)hd_k);

  for (size_t li = 0; li < w_.layers.size(); ++li) {
    const auto& L = w_.layers[li];
    auto& cache = cache_[li];

    rmsnorm_vec(x.data(), L.attn_norm.data(), xn.data(), n_embd, eps);

    // ---- LFM2: camadas shortconv ----
    if (L.shortconv.present) {
      const int K = C.conv_kernel;
      // scratch precisa de 3*n_embd
      static thread_local std::vector<float> sc;
      if ((int)sc.size() < 3 * n_embd) sc.resize(3 * n_embd);
      shortconv_op(xn.data(), L.shortconv,
                   conv_cache_[li].buf.data(), n_embd, K, n_embd,
                   attn_proj.data(), sc.data());
      // out_proj
      linear_qt(attn_proj.data(), L.shortconv.out_proj,
                attn_proj.data(), n_embd, n_embd);
      for (int i = 0; i < n_embd; ++i) x[i] += attn_proj[i];
      // pula direto para o FFN
      rmsnorm_vec(x.data(), L.ffn_norm.data(), xn.data(), n_embd, eps);
      linear_qt(xn.data(), L.ffn_gate, gate.data(), n_embd, n_ff);
      linear_qt(xn.data(), L.ffn_up,   up.data(),   n_embd, n_ff);
      if (C.activation == Activation::GELU) {
        for (int i = 0; i < n_ff; ++i) gate[i] = gelu_tanh(gate[i]) * up[i];
      } else {
        for (int i = 0; i < n_ff; ++i) {
          const float g = gate[i];
          gate[i] = (g / (1.0f + std::exp(-g))) * up[i];
        }
      }
      linear_qt(gate.data(), L.ffn_down, ffn_out.data(), n_ff, n_embd);
      for (int i = 0; i < n_embd; ++i) x[i] += ffn_out[i];
      continue;
    }

    // ---- atenção normal ----
    linear_qt(xn.data(), L.attn_q, q.data(), n_embd, n_embd_q);
    add_bias(q.data(), L.attn_q_bias, n_embd_q);
    linear_qt(xn.data(), L.attn_k, k.data(), n_embd, n_embd_kv);
    add_bias(k.data(), L.attn_k_bias, n_embd_kv);
    linear_qt(xn.data(), L.attn_v, v.data(), n_embd, n_embd_v);
    add_bias(v.data(), L.attn_v_bias, n_embd_v);

    // QK norm (Qwen3, Gemma-3) antes do RoPE
    if (!L.attn_q_norm.empty())
      qk_norm_apply(q.data(), n_head,    hd_k, L.attn_q_norm.data(), eps);
    if (!L.attn_k_norm.empty())
      qk_norm_apply(k.data(), n_head_kv, hd_k, L.attn_k_norm.data(), eps);

    rope_vec(q.data(), n_head,    hd_k, pos, theta);
    rope_vec(k.data(), n_head_kv, hd_k, pos, theta);

    std::memcpy(cache.k.data() + (size_t)pos*n_embd_kv, k.data(), n_embd_kv*4);
    std::memcpy(cache.v.data() + (size_t)pos*n_embd_v,  v.data(), n_embd_v*4);

    std::fill(attn_out.begin(), attn_out.end(), 0.0f);

    for (int h = 0; h < n_head; ++h) {
      const float* qh = q.data() + (size_t)h * hd_k;
      const int kv_h = h / group;
      float max_s = -1e30f;
      for (int i = 0; i <= pos; ++i) {
        const float* ki = cache.k.data() + (size_t)i*n_embd_kv + (size_t)kv_h*hd_k;
        float s = 0.0f;
        for (int d = 0; d < hd_k; ++d) s += qh[d]*ki[d];
        s *= scale; scores[i] = s;
        if (s > max_s) max_s = s;
      }
      float sum = 0.0f;
      for (int i = 0; i <= pos; ++i) { scores[i] = std::exp(scores[i]-max_s); sum += scores[i]; }
      const float inv = 1.0f / sum;
      float* oh = attn_out.data() + (size_t)h * hd_v;
      for (int d = 0; d < hd_v; ++d) oh[d] = 0.0f;
      for (int i = 0; i <= pos; ++i) {
        const float w = scores[i] * inv;
        const float* vi = cache.v.data() + (size_t)i*n_embd_v + (size_t)kv_h*hd_v;
        for (int d = 0; d < hd_v; ++d) oh[d] += w * vi[d];
      }
    }

    linear_qt(attn_out.data(), L.attn_output, attn_proj.data(), n_embd_q, n_embd);

    // Gemma-3: attn_post_norm antes do residual
    if (!L.attn_post_norm.empty())
      rmsnorm_vec(attn_proj.data(), L.attn_post_norm.data(),
                  attn_proj.data(), n_embd, eps);

    for (int i = 0; i < n_embd; ++i) x[i] += attn_proj[i];

    rmsnorm_vec(x.data(), L.ffn_norm.data(), xn.data(), n_embd, eps);
    linear_qt(xn.data(), L.ffn_gate, gate.data(), n_embd, n_ff);
    linear_qt(xn.data(), L.ffn_up,   up.data(),   n_embd, n_ff);

    if (C.activation == Activation::GELU) {
      for (int i = 0; i < n_ff; ++i) gate[i] = gelu_tanh(gate[i]) * up[i];
    } else {
      for (int i = 0; i < n_ff; ++i) {
        const float g = gate[i];
        gate[i] = (g / (1.0f + std::exp(-g))) * up[i];
      }
    }

    linear_qt(gate.data(), L.ffn_down, ffn_out.data(), n_ff, n_embd);

    if (!L.ffn_post_norm.empty())
      rmsnorm_vec(ffn_out.data(), L.ffn_post_norm.data(),
                  ffn_out.data(), n_embd, eps);

    for (int i = 0; i < n_embd; ++i) x[i] += ffn_out[i];

    // Gemma-3: escala final da camada
    if (!L.layer_output_scale.empty()) {
      const float s = L.layer_output_scale[0];
      for (int i = 0; i < n_embd; ++i) x[i] *= s;
    }
  }

  rmsnorm_vec(x.data(), w_.output_norm.data(), xn.data(), n_embd, eps);

  std::vector<float> logits(n_vocab);
  linear_qt(xn.data(), w_.output, logits.data(), n_embd, n_vocab);

  // Gemma-2/3: softcap final
  if (C.final_logit_softcap > 0.0f) {
    const float cap = C.final_logit_softcap;
    for (auto& v : logits) v = std::tanh(v / cap) * cap;
  }
  return logits;
}

int32_t argmax(const std::vector<float>& v) {
  int32_t best = 0; float bv = v[0];
  for (size_t i = 1; i < v.size(); ++i) if (v[i] > bv) { bv = v[i]; best = (int32_t)i; }
  return best;
}

int32_t sample(std::vector<float>& logits, const std::vector<int32_t>& history,
               const SampleOpts& opts, uint64_t& rng_state) {
  if (opts.repeat_penalty > 1.0f && !history.empty()) {
    int n = std::min((int)history.size(), opts.repeat_last_n);
    int start = (int)history.size() - n;
    for (int i = start; i < (int)history.size(); ++i) {
      int32_t t = history[i];
      if (t < 0 || (size_t)t >= logits.size()) continue;
      float& v = logits[t];
      if (v > 0) v /= opts.repeat_penalty; else v *= opts.repeat_penalty;
    }
  }
  if (opts.temp > 0.0f) {
    float it = 1.0f / opts.temp;
    for (auto& v : logits) v *= it;
  } else return argmax(logits);

  std::vector<std::pair<float,int32_t>> items;
  items.reserve(logits.size());
  for (size_t i = 0; i < logits.size(); ++i) items.emplace_back(logits[i], (int32_t)i);
  std::sort(items.begin(), items.end(),
            [](const auto& a, const auto& b){ return a.first > b.first; });

  if (opts.top_k > 0 && (size_t)opts.top_k < items.size()) items.resize(opts.top_k);

  float mv = items[0].first, sum = 0.0f;
  for (auto& it : items) { it.first = std::exp(it.first - mv); sum += it.first; }
  for (auto& it : items) it.first /= sum;

  if (opts.top_p < 1.0f) {
    float cum = 0.0f; size_t cut = items.size();
    for (size_t i = 0; i < items.size(); ++i) {
      cum += items[i].first;
      if (cum >= opts.top_p) { cut = i+1; break; }
    }
    if (cut < items.size()) items.resize(cut);
    float s2 = 0.0f; for (auto& it : items) s2 += it.first;
    for (auto& it : items) it.first /= s2;
  }

  if (rng_state == 0) rng_state = 0x9E3779B97F4A7C15ULL;
  rng_state ^= rng_state >> 12; rng_state ^= rng_state << 25; rng_state ^= rng_state >> 27;
  const uint64_t r = rng_state * 0x2545F4914F6CDD1DULL;
  const float u = (float)((r >> 11) * (1.0/9007199254740992.0));
  float acc = 0.0f;
  for (const auto& it : items) { acc += it.first; if (u <= acc) return it.second; }
  return items.back().second;
}

}  // namespace luna::models
