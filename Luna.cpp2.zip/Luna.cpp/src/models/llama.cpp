#include "models/llama.hpp"

#include <cmath>
#include <cstdio>
#include <stdexcept>

namespace luna::models {

bool LlamaModel::load(io::GgufFile& file) {
  const auto& m = file.metadata;
  const std::string arch = file.arch();
  const std::string prefix = arch + ".";
  std::printf("[config] architecture: %s\n", arch.c_str());

  auto get_i32 = [&](const std::string& k, int32_t def) -> int32_t {
    auto it = m.find(k);
    if (it == m.end()) return def;
    if (auto p = std::get_if<uint32_t>(&it->second)) return static_cast<int32_t>(*p);
    if (auto p = std::get_if<int32_t>(&it->second))  return *p;
    if (auto p = std::get_if<uint64_t>(&it->second)) return static_cast<int32_t>(*p);
    return def;
  };
  auto get_f32 = [&](const std::string& k, float def) -> float {
    auto it = m.find(k);
    if (it == m.end()) return def;
    if (auto p = std::get_if<float>(&it->second)) return *p;
    return def;
  };

  config.n_vocab     = get_i32(prefix + "vocab_size", 0);
  config.n_ctx_train = get_i32(prefix + "context_length", 0);
  config.n_embd      = get_i32(prefix + "embedding_length", 0);
  config.n_layer     = get_i32(prefix + "block_count", 0);
  config.n_head      = get_i32(prefix + "attention.head_count", 0);
  config.n_head_kv   = get_i32(prefix + "attention.head_count_kv", config.n_head);
  config.n_ff        = get_i32(prefix + "feed_forward_length", 0);
  config.rope_theta  = get_f32(prefix + "rope.freq_base", 10000.0f);
  config.rms_eps     = get_f32(prefix + "attention.layer_norm_rms_epsilon", 1e-5f);

  config.head_dim_k = get_i32(prefix + "attention.key_length", 0);
  config.head_dim_v = get_i32(prefix + "attention.value_length", 0);
  if (config.head_dim_k == 0 && config.n_head > 0)
    config.head_dim_k = config.n_embd / config.n_head;
  if (config.head_dim_v == 0)
    config.head_dim_v = config.head_dim_k;

  // ---- features por arquitetura ----
  const bool is_gemma = arch.rfind("gemma", 0) == 0;
  const bool is_qwen3 = arch.rfind("qwen3", 0) == 0;

  if (is_gemma) {
    config.activation  = Activation::GELU;
    config.norm_add_one = true;
    config.embd_scale   = std::sqrt((float)config.n_embd);
    config.final_logit_softcap = get_f32(prefix + "final_logit_softcapping", 0.0f);
    config.sliding_window = get_i32(prefix + "attention.sliding_window", 0);
    config.post_norm_attn = file.find("blk.0.attn_post_norm.weight") != nullptr || file.find("blk.0.post_attention_norm.weight") != nullptr;
    config.post_norm_ffn  = (file.find("blk.0.post_ffw_norm.weight") != nullptr) ||
                            (file.find("blk.0.ffn_post_norm.weight") != nullptr);
    config.qk_norm = file.find("blk.0.attn_q_norm.weight") != nullptr;
    config.layer_output_scale = file.find("blk.0.layer_output_scale.weight") != nullptr;
  }
  if (is_qwen3) {
    config.qk_norm = true;
  }

  // LFM2: híbrido shortconv + attention
  const bool is_lfm2 = arch.rfind("lfm2", 0) == 0;
  if (is_lfm2) {
    config.layer_types.resize(config.n_layer);
    int n_conv = 0, n_attn = 0;
    for (int32_t i = 0; i < config.n_layer; ++i) {
      std::string p2 = "blk." + std::to_string(i) + ".shortconv.conv.weight";
      if (file.find(p2)) {
        config.layer_types[i] = LayerType::ShortConv;
        ++n_conv;
      } else {
        config.layer_types[i] = LayerType::Attention;
        ++n_attn;
      }
    }
    config.conv_kernel = 3;
    std::printf("[config] LFM2: %d conv + %d attn\n", n_conv, n_attn);
    // Mostra o mapa
    std::printf("[config] layer map: ");
    for (size_t i = 0; i < config.layer_types.size(); ++i)
      std::printf("%c", config.layer_types[i] == LayerType::ShortConv ? 'C' : 'A');
    std::printf("\n");
  }

  std::printf("[config] features: act=%s qk_norm=%d post_attn=%d post_ffn=%d "
              "layer_scale=%d norm+1=%d embd_scale=%.1f softcap=%.1f\n",
              config.activation == Activation::GELU ? "GELU" : "SiLU",
              config.qk_norm, config.post_norm_attn, config.post_norm_ffn,
              config.layer_output_scale, config.norm_add_one,
              config.embd_scale, config.final_logit_softcap);

  auto it_tok = m.find("tokenizer.ggml.tokens");
  auto it_scr = m.find("tokenizer.ggml.scores");
  if (it_tok != m.end()) {
    if (auto p = std::get_if<std::vector<std::string>>(&it_tok->second))
      vocab_ = *p;
  }
  if (it_scr != m.end()) {
    if (auto p = std::get_if<std::vector<float>>(&it_scr->second))
      vocab_scores_ = *p;
  }
  if (config.n_vocab == 0 && !vocab_.empty())
    config.n_vocab = static_cast<int32_t>(vocab_.size());

  return config.n_layer > 0 && config.n_embd > 0;
}

void LlamaModel::print_summary() const {
  std::printf("== config ==\n");
  std::printf("  vocab        : %d\n", config.n_vocab);
  std::printf("  ctx_train    : %d\n", config.n_ctx_train);
  std::printf("  n_embd       : %d\n", config.n_embd);
  std::printf("  n_layer      : %d\n", config.n_layer);
  std::printf("  n_head       : %d\n", config.n_head);
  std::printf("  n_head_kv    : %d\n", config.n_head_kv);
  std::printf("  n_ff         : %d\n", config.n_ff);
  std::printf("  head_dim_k   : %d\n", config.head_dim_k);
  std::printf("  head_dim_v   : %d\n", config.head_dim_v);
  std::printf("  rope_theta   : %.1f\n", config.rope_theta);
  std::printf("  rms_eps      : %g\n",  config.rms_eps);
}

}  // namespace luna::models
