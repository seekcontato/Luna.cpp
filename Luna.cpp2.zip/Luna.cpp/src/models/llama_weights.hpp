#pragma once

#include "io/gguf.hpp"
#include "models/llama.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace luna::models {

// Pesos em bytes crus (F16, Q4_K, Q6_K, etc.) — mantém Q4 na RAM
struct QuantTensor {
  std::vector<uint8_t> data;
  io::GgmlType type = io::GgmlType::F16;
  int64_t n_in  = 0;
  int64_t n_out = 0;
  bool empty() const { return data.empty(); }
  bool is_f16() const { return type == io::GgmlType::F16; }
};

struct ShortConvWeights {
  QuantTensor in_proj;                // [n_embd, 3*n_embd]
  std::vector<float> conv;            // [kernel, n_embd] (F32)
  QuantTensor out_proj;               // [n_embd, n_embd]
  bool present = false;
};

struct LayerWeights {
  std::vector<float> attn_norm;
  QuantTensor attn_q, attn_k, attn_v, attn_output;
  std::vector<float> attn_q_bias, attn_k_bias, attn_v_bias;

  // Opcionais (Qwen3/Gemma-3)
  std::vector<float> attn_q_norm;   // [head_dim_k]
  std::vector<float> attn_k_norm;   // [head_dim_k]
  std::vector<float> attn_post_norm; // [n_embd] (Gemma-3)
  std::vector<float> ffn_post_norm;  // [n_embd] (Gemma-3)
  std::vector<float> layer_output_scale; // [1] (Gemma-3)

  std::vector<float> ffn_norm;
  QuantTensor ffn_gate, ffn_up, ffn_down;

  // LFM2
  ShortConvWeights shortconv;
};

class LlamaWeights {
 public:
  LlamaConfig config;
  int32_t head_dim_k = 0;
  int32_t head_dim_v = 0;
  int32_t n_embd_q   = 0;
  int32_t n_embd_kv  = 0;
  int32_t n_embd_v   = 0;

  QuantTensor        token_embd;
  std::vector<float> output_norm;
  QuantTensor        output;

  std::vector<LayerWeights> layers;

  bool load(io::GgufFile& file);
};

}  // namespace luna::models
