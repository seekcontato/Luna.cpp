#include "models/llama_weights.hpp"
#include <cstdio>
#include <stdexcept>

namespace luna::models {

namespace {

std::vector<float> load_f32(io::GgufFile& f, const std::string& n) {
  const auto* i = f.find(n);
  if (!i) throw std::runtime_error("peso não encontrado: " + n);
  return f.read_f32(*i);
}
[[maybe_unused]] std::vector<uint16_t> load_f16(io::GgufFile& f, const std::string& n) {
  const auto* i = f.find(n);
  if (!i) throw std::runtime_error("peso não encontrado: " + n);
  return f.read_f16(*i);
}
std::vector<float> load_f32_opt(io::GgufFile& f, const std::string& n) {
  const auto* i = f.find(n);
  if (!i) return {};
  return f.read_f32(*i);
}

QuantTensor load_qt(io::GgufFile& f, const std::string& n,
                    int64_t n_in, int64_t n_out) {
  const auto* i = f.find(n);
  if (!i) throw std::runtime_error("peso não encontrado: " + n);
  QuantTensor qt;
  qt.data  = f.read_raw(*i);
  qt.type  = i->type;
  qt.n_in  = n_in;
  qt.n_out = n_out;
  return qt;
}

// Norm: aplica +1 se norm_add_one (Gemma)
std::vector<float> load_norm(io::GgufFile& f, const std::string& n, bool add_one) {
  auto v = load_f32(f, n);
  if (add_one) for (auto& x : v) x += 1.0f;
  return v;
}

[[maybe_unused]] std::vector<uint16_t> reshape_embd(std::vector<uint16_t> raw,
                                    int32_t n_vocab, int32_t n_embd) {
  std::vector<uint16_t> out(raw.size());
  for (int32_t t = 0; t < n_vocab; ++t)
    for (int32_t i = 0; i < n_embd; ++i)
      out[(size_t)t*n_embd + i] = raw[(size_t)i + (size_t)t*n_embd];
  return out;
}

}  // namespace

bool LlamaWeights::load(io::GgufFile& file) {
  LlamaModel m;
  if (!m.load(file)) throw std::runtime_error("config inválida");
  config = m.config;
  if (config.n_head <= 0) throw std::runtime_error("n_head=0");

  head_dim_k = config.head_dim_k;
  head_dim_v = config.head_dim_v;
  n_embd_q   = config.n_head    * head_dim_k;
  n_embd_kv  = config.n_head_kv * head_dim_k;
  n_embd_v   = config.n_head_kv * head_dim_v;

  std::printf("[weights] vocab=%d embd=%d layer=%d head=%d kv=%d ff=%d "
              "hd_k=%d hd_v=%d\n",
              config.n_vocab, config.n_embd, config.n_layer,
              config.n_head, config.n_head_kv, config.n_ff,
              head_dim_k, head_dim_v);

  const bool add_one = config.norm_add_one;

  std::printf("[weights] carregando embedding...\n"); std::fflush(stdout);
  {
    token_embd = load_qt(file, "token_embd.weight", config.n_embd, config.n_vocab);
  }
  // LFM2 usa "token_embd_norm.weight" em vez de "output_norm.weight"
  if (file.find("output_norm.weight"))
    if (file.find("output_norm.weight")) {
    output_norm = load_norm(file, "output_norm.weight", add_one);
  } else if (file.find("token_embd_norm.weight")) {
    output_norm = load_norm(file, "token_embd_norm.weight", add_one);
  } else {
    throw std::runtime_error("norm final não encontrada");
  }
  else if (file.find("token_embd_norm.weight"))
    output_norm = load_norm(file, "token_embd_norm.weight", add_one);
  else
    throw std::runtime_error("norm final não encontrada");

  if (file.find("output.weight")) {
    std::printf("[weights] carregando output...\n"); std::fflush(stdout);
    output = load_qt(file, "output.weight", config.n_embd, config.n_vocab);
  } else {
    std::printf("[weights] output tied\n");
    output = token_embd;
  }

  // Detecta nome da post-norm FFN
  const bool post_ffn_is_post_ffw =
    file.find("blk.0.post_ffw_norm.weight") != nullptr;

  layers.resize(config.n_layer);
  for (int32_t i = 0; i < config.n_layer; ++i) {
    if ((i % 8) == 0 || i == config.n_layer - 1) {
      std::printf("[weights] camada %d/%d\n", i+1, config.n_layer);
      std::fflush(stdout);
    }
    const std::string p = "blk." + std::to_string(i) + ".";
    auto& L = layers[i];

    // LFM2: alterna shortconv e attention
    const bool is_shortconv = !config.layer_types.empty() &&
        config.layer_types[i] == LayerType::ShortConv;

    if (is_shortconv) {
      // Carrega pesos de shortconv
      L.shortconv.in_proj  = load_qt(file, p + "shortconv.in_proj.weight",
                                     config.n_embd, 3 * config.n_embd);
      L.shortconv.conv     = load_f32(file, p + "shortconv.conv.weight");
      L.shortconv.out_proj = load_qt(file, p + "shortconv.out_proj.weight",
                                     config.n_embd, config.n_embd);
      L.shortconv.present  = true;
    } else {
      L.attn_q      = load_qt(file, p + "attn_q.weight", config.n_embd, n_embd_q);
      L.attn_q_bias = load_f32_opt(file, p + "attn_q.bias");
      L.attn_k      = load_qt(file, p + "attn_k.weight", config.n_embd, n_embd_kv);
      L.attn_k_bias = load_f32_opt(file, p + "attn_k.bias");
      L.attn_v      = load_qt(file, p + "attn_v.weight", config.n_embd, n_embd_v);
      L.attn_v_bias = load_f32_opt(file, p + "attn_v.bias");
      L.attn_output = load_qt(file, p + "attn_output.weight", n_embd_q, config.n_embd);

      if (config.qk_norm) {
        L.attn_q_norm = load_norm(file, p + "attn_q_norm.weight", add_one);
        L.attn_k_norm = load_norm(file, p + "attn_k_norm.weight", add_one);
      }
    }

    // attn_norm existe em AMBOS os tipos (no LFM2 é o norm de entrada)
    L.attn_norm = load_norm(file, p + "attn_norm.weight", add_one);
    if (config.post_norm_attn) {
      const std::string post_attn_name =
        file.find(p + "attn_post_norm.weight")
          ? (p + "attn_post_norm.weight")
          : (p + "post_attention_norm.weight");
      L.attn_post_norm = load_norm(file, post_attn_name, add_one);
    }
    if (config.post_norm_ffn) {
      const std::string ffn_post = post_ffn_is_post_ffw
        ? (p + "post_ffw_norm.weight")
        : (p + "ffn_post_norm.weight");
      L.ffn_post_norm = load_norm(file, ffn_post, add_one);
    }
    if (config.layer_output_scale) {
      L.layer_output_scale = load_f32_opt(file, p + "layer_output_scale.weight");
    }

    L.ffn_norm = load_norm(file, p + "ffn_norm.weight", add_one);
    L.ffn_gate = load_qt(file, p + "ffn_gate.weight", config.n_embd, config.n_ff);
    L.ffn_up   = load_qt(file, p + "ffn_up.weight", config.n_embd, config.n_ff);
    L.ffn_down = load_qt(file, p + "ffn_down.weight", config.n_ff, config.n_embd);
  }

  std::printf("[weights] %zu camadas OK\n", layers.size());
  return true;
}

}  // namespace luna::models
