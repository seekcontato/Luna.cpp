#pragma once

#include "models/llama_weights.hpp"
#include <cstdint>
#include <vector>

namespace luna::models {

class LlamaForward {
 public:
  explicit LlamaForward(const LlamaWeights& w, int32_t n_ctx = 2048);

  void reset();
  std::vector<float> forward_token(int32_t token, int32_t pos);

  int32_t n_ctx() const { return n_ctx_; }

 private:
  const LlamaWeights& w_;
  int32_t n_ctx_;

  struct LayerCache {
    std::vector<float> k;  // [n_ctx * n_embd_kv]
    std::vector<float> v;  // [n_ctx * n_embd_v]
  };
  std::vector<LayerCache> cache_;

  // LFM2: buffer de conv por camada (kernel-1 = 2 vetores de n_embd)
  struct ConvState { std::vector<float> buf; };
  std::vector<ConvState> conv_cache_;
};

int32_t argmax(const std::vector<float>& v);

struct SampleOpts {
  float    temp            = 0.7f;
  int      top_k           = 40;
  float    top_p           = 0.9f;
  float    repeat_penalty  = 1.1f;
  int      repeat_last_n   = 64;
  int32_t  eos_id          = -1;
};

int32_t sample(std::vector<float>& logits,
               const std::vector<int32_t>& history,
               const SampleOpts& opts,
               uint64_t& rng_state);

}  // namespace luna::models
