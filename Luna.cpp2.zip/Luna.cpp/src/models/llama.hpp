#pragma once

#include "io/gguf.hpp"
#include <string>
#include <vector>

namespace luna::models {

enum class Activation { SiLU, GELU };
enum class LayerType  { Attention, ShortConv };

struct LlamaConfig {
  int32_t n_vocab      = 0;
  int32_t n_ctx_train  = 0;
  int32_t n_embd       = 0;
  int32_t n_layer      = 0;
  int32_t n_head       = 0;
  int32_t n_head_kv    = 0;
  int32_t n_ff         = 0;
  int32_t head_dim_k   = 0;
  int32_t head_dim_v   = 0;
  float   rope_theta   = 10000.0f;
  float   rms_eps      = 1e-5f;

  // Features estendidas
  Activation activation = Activation::SiLU;
  bool  qk_norm            = false;   // Qwen3, Gemma-3
  bool  post_norm_attn     = false;   // Gemma-3
  bool  post_norm_ffn      = false;   // Gemma-3
  bool  layer_output_scale = false;   // Gemma-3
  bool  norm_add_one       = false;   // Gemma-2/3: pesos de norm são (1 + w)
  float embd_scale         = 1.0f;    // Gemma: sqrt(n_embd)
  float final_logit_softcap = 0.0f;   // Gemma-2/3: tanh softcap
  int   sliding_window     = 0;       // Gemma-3 (ignorado por ora)

  // LFM2 (híbrido)
  std::vector<LayerType> layer_types;   // tamanho n_layer
  int32_t conv_kernel = 0;              // 3 no LFM2
};

class LlamaModel {
 public:
  LlamaConfig config;

  bool load(io::GgufFile& file);
  void print_summary() const;

  const std::vector<std::string>& vocab() const { return vocab_; }

 private:
  std::vector<std::string> vocab_;
  std::vector<float>       vocab_scores_;
};

}  // namespace luna::models
