#pragma once

#include "util/model_finder.hpp"
#include <string>
#include <vector>

namespace luna::util {

// Seletor interativo de modelos.
// Usa setas ↑/↓ para navegar, Enter para confirmar, q para sair.
// Retorna o path escolhido, ou "" se cancelou.
std::string pick_model(const std::vector<ModelEntry>& models,
                       const std::string& title = "Escolha um modelo");

// Modo não-interativo (fallback): lista numerada, usuário digita o número.
std::string pick_model_numbered(const std::vector<ModelEntry>& models);

// Detecta se stdin é um TTY interativo
bool stdin_is_tty();

}  // namespace luna::util
