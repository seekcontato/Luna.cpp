#include "util/memory.hpp"

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <ctime>

namespace fs = std::filesystem;

namespace luna::util {

namespace {

std::string now_iso() {
  std::time_t t = std::time(nullptr);
  char buf[32];
  std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%S", std::gmtime(&t));
  return buf;
}

std::string json_escape(const std::string& s) {
  std::string o;
  for (char c : s) {
    switch (c) {
      case '"':  o += "\\\""; break;
      case '\\': o += "\\\\"; break;
      case '\n': o += "\\n";  break;
      case '\r': o += "\\r";  break;
      case '\t': o += "\\t";  break;
      default:   o += c;
    }
  }
  return o;
}

std::string json_unescape(const std::string& s) {
  std::string o;
  for (size_t i = 0; i < s.size(); ++i) {
    if (s[i] == '\\' && i+1 < s.size()) {
      char n = s[++i];
      switch (n) {
        case 'n': o += '\n'; break;
        case 'r': o += '\r'; break;
        case 't': o += '\t'; break;
        case '"': o += '"';  break;
        case '\\': o += '\\'; break;
        default: o += n;
      }
    } else o += s[i];
  }
  return o;
}

// Extrai string de campo "key":"value" em JSON de uma linha
std::string get_field(const std::string& line, const std::string& key) {
  std::string k = "\"" + key + "\":\"";
  auto p = line.find(k);
  if (p == std::string::npos) return "";
  p += k.size();
  std::string out;
  for (size_t i = p; i < line.size(); ++i) {
    if (line[i] == '\\' && i+1 < line.size()) {
      out += line[i]; out += line[i+1]; ++i; continue;
    }
    if (line[i] == '"') break;
    out += line[i];
  }
  return json_unescape(out);
}

std::string home_dir() {
  const char* h = std::getenv("HOME");
  return h ? h : ".";
}

}  // namespace

bool Memory::open(const std::string& name) {
  std::string dir = home_dir() + "/.luna/sessions";
  std::error_code ec;
  fs::create_directories(dir, ec);
  path_ = dir + "/" + name + ".jsonl";
  load();
  return true;
}

void Memory::load() {
  entries_.clear();
  std::ifstream f(path_);
  if (!f) return;
  std::string line;
  while (std::getline(f, line)) {
    if (line.empty()) continue;
    MemoryEntry e;
    e.ts      = get_field(line, "ts");
    e.role    = get_field(line, "role");
    e.content = get_field(line, "content");
    if (!e.role.empty()) entries_.push_back(std::move(e));
  }
}

void Memory::append(const std::string& role, const std::string& content) {
  std::ofstream f(path_, std::ios::app);
  if (!f) return;
  std::string line = "{\"ts\":\"" + now_iso() +
                     "\",\"role\":\"" + json_escape(role) +
                     "\",\"content\":\"" + json_escape(content) + "\"}\n";
  f << line;
  entries_.push_back({now_iso(), role, content});
}

std::vector<MemoryEntry> Memory::last(int n) const {
  if ((int)entries_.size() <= n) return entries_;
  return std::vector<MemoryEntry>(entries_.end() - n, entries_.end());
}

std::vector<MemoryEntry> Memory::search(const std::string& needle, int max) const {
  std::string n = needle;
  for (auto& c : n) c = (char)std::tolower((unsigned char)c);

  std::vector<MemoryEntry> out;
  for (auto it = entries_.rbegin(); it != entries_.rend(); ++it) {
    std::string h = it->content;
    for (auto& c : h) c = (char)std::tolower((unsigned char)c);
    if (h.find(n) != std::string::npos) {
      out.push_back(*it);
      if ((int)out.size() >= max) break;
    }
  }
  return out;
}

void Memory::clear() {
  entries_.clear();
  std::remove(path_.c_str());
}

}  // namespace luna::util
