#include "util/selector.hpp"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>
#include <termios.h>
#include <unistd.h>

namespace luna::util {

bool stdin_is_tty() {
  return isatty(fileno(stdin)) != 0;
}

namespace {

// RAII para colocar o terminal em modo raw
struct RawMode {
  termios orig{};
  bool ok = false;

  RawMode() {
    if (tcgetattr(STDIN_FILENO, &orig) != 0) return;
    termios raw = orig;
    raw.c_lflag &= ~(unsigned)(ICANON | ECHO);
    raw.c_cc[VMIN]  = 1;
    raw.c_cc[VTIME] = 0;
    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) == 0) ok = true;
  }
  ~RawMode() {
    if (ok) tcsetattr(STDIN_FILENO, TCSAFLUSH, &orig);
  }
};

// Lê próxima tecla (raw). Retorna código ANSI ou ASCII.
//   - Up:    "\x1b[A" -> 1001
//   - Down:  "\x1b[B" -> 1002
//   - Enter: '\n' ou '\r'
//   - q, ESC: código cru
int read_key() {
  char c = 0;
  if (read(STDIN_FILENO, &c, 1) != 1) return -1;

  if (c == 0x1b) {
    char seq[2];
    if (read(STDIN_FILENO, &seq[0], 1) != 1) return 0x1b;
    if (seq[0] == '[') {
      if (read(STDIN_FILENO, &seq[1], 1) != 1) return 0x1b;
      if (seq[1] == 'A') return 1001;
      if (seq[1] == 'B') return 1002;
      return 0x1b;
    }
    return 0x1b;
  }
  return (unsigned char)c;
}

// Quebra nome em [prefixo_ansi, visível, sufixo]
std::string truncate(const std::string& s, size_t max) {
  if (s.size() <= max) return s;
  if (max < 4) return s.substr(0, max);
  return s.substr(0, max - 3) + "...";
}

}  // namespace

std::string pick_model(const std::vector<ModelEntry>& models,
                       const std::string& title) {
  if (models.empty()) return "";
  if (models.size() == 1) return models[0].path;

  // Tenta interativo. Se não é TTY, cai pro numerado.
  if (!stdin_is_tty()) return pick_model_numbered(models);

  RawMode raw;
  if (!raw.ok) return pick_model_numbered(models);

  int cur = 0;
  const int N = (int)models.size();

  auto render = [&]{
    // Esconde cursor
    std::fputs("\x1b[?25l", stdout);
    // Pula pro topo se já desenhamos
    std::printf("\x1b[2J\x1b[H");
    std::printf("\x1b[1;36m%s\x1b[0m\n", title.c_str());
    std::printf("\x1b[2m↑/↓ navega · Enter escolhe · q sai\x1b[0m\n\n");

    for (int i = 0; i < N; ++i) {
      const auto& m = models[i];
      std::string size_s = human_size(m.bytes);
      // Nome visível alinhado
      std::string name = truncate(m.name, 55);
      if (!m.arch.empty()) name += "  [" + m.arch + "]";

      if (i == cur) {
        std::printf("\x1b[7m ▶ %-8s  %-60s \x1b[0m\n",
                    size_s.c_str(), name.c_str());
      } else {
        std::printf("   %-8s  %-60s \n",
                    size_s.c_str(), name.c_str());
      }
      // Mostra o diretório apenas para o item selecionado
      if (i == cur) {
        // diretório pai
        size_t slash = m.path.find_last_of('/');
        std::string dir = (slash == std::string::npos)
                            ? m.path : m.path.substr(0, slash);
        std::printf("\x1b[2m     %s\x1b[0m\n", dir.c_str());
      }
    }
    std::printf("\n");
    std::fflush(stdout);
  };

  render();

  for (;;) {
    int k = read_key();
    if (k == 1001) { if (cur > 0) --cur; render(); }         // up
    else if (k == 1002) { if (cur < N-1) ++cur; render(); }  // down
    else if (k == '\n' || k == '\r') break;                  // enter
    else if (k == 'q' || k == 'Q' || k == 0x1b || k == 3) {  // q / esc / ctrl-c
      std::fputs("\x1b[?25h\x1b[2J\x1b[H", stdout);
      return "";
    }
    else if (k >= '1' && k <= '9') {
      // atalho numérico
      int idx = k - '1';
      if (idx < N) { cur = idx; render(); }
    }
  }

  // Restaura cursor e limpa
  std::fputs("\x1b[?25h", stdout);
  std::printf("\x1b[2J\x1b[H");
  std::fflush(stdout);

  return models[cur].path;
}

std::string pick_model_numbered(const std::vector<ModelEntry>& models) {
  if (models.empty()) return "";

  std::printf("\nModelos disponíveis:\n\n");
  for (size_t i = 0; i < models.size(); ++i) {
    std::printf("  \x1b[1;33m%2zu\x1b[0m) %-8s  %s\n",
                i + 1,
                human_size(models[i].bytes).c_str(),
                models[i].name.c_str());
  }
  std::printf("\n");

  for (;;) {
    std::printf("Escolha [1-%zu] (0 cancela): ", models.size());
    std::fflush(stdout);

    std::string line;
    if (!std::getline(std::cin, line)) return "";
    if (line.empty()) continue;

    char* end = nullptr;
    long v = std::strtol(line.c_str(), &end, 10);
    if (end == line.c_str()) continue;
    if (v == 0) return "";
    if (v >= 1 && (size_t)v <= models.size())
      return models[(size_t)v - 1].path;
  }
}

}  // namespace luna::util
