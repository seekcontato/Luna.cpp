#pragma once

#include <string>
#include <vector>

namespace luna::util {

struct ModelEntry {
  std::string name;         // nome do arquivo
  std::string path;         // caminho completo
  uint64_t    bytes;        // tamanho
  std::string arch;         // arquitetura lida do GGUF (llama, qwen2, ...)
  bool        supported;    // true se o Luna.cpp roda esse modelo
};

// Lê só o cabeçalho do GGUF pra descobrir a arquitetura (rápido).
// Não carrega pesos.
bool probe_arch(const std::string& path, std::string& arch_out);

// Retorna true para arquiteturas que o Luna.cpp carrega
bool is_supported_arch(const std::string& arch);

// Diretórios padrão onde procurar modelos GGUF.
// A ordem importa: os primeiros são preferidos.
std::vector<std::string> default_model_dirs();

// Adiciona diretórios customizados (via env LUNA_MODEL_PATH, separados por ':')
void add_dirs_from_env(std::vector<std::string>& dirs);

// Lista todos os .gguf encontrados nos diretórios padrão
std::vector<ModelEntry> list_models();

// Resolve um "query" para um caminho de arquivo.
//   - Se query é um caminho existente, retorna direto.
//   - Se query termina em .gguf, procura por nome exato.
//   - Caso contrário, faz match parcial (substring) e retorna o melhor.
// Retorna "" se não achar.
std::string resolve_model(const std::string& query);

// Formata bytes como "123 MB" / "1.2 GB"
std::string human_size(uint64_t bytes);

}  // namespace luna::util
