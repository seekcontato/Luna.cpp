#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace luna::util {

struct MemoryEntry {
  std::string ts;       // ISO 8601
  std::string role;     // "user" | "assistant"
  std::string content;
};

class Memory {
 public:
  // Abre/cria arquivo em ~/.luna/sessions/<name>.jsonl
  bool open(const std::string& name = "default");

  // Grava uma mensagem imediatamente em disco
  void append(const std::string& role, const std::string& content);

  // Carrega tudo do disco para a memória RAM
  void load();

  // Devolve as últimas `n` entradas
  std::vector<MemoryEntry> last(int n) const;

  // Busca por substring no conteúdo (case-insensitive)
  std::vector<MemoryEntry> search(const std::string& needle, int max = 20) const;

  // Apaga o arquivo da sessão
  void clear();

  size_t size() const { return entries_.size(); }
  const std::string& path() const { return path_; }

 private:
  std::string path_;
  std::vector<MemoryEntry> entries_;
};

}  // namespace luna::util
