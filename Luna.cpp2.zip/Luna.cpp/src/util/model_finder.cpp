#include "util/model_finder.hpp"
#include "io/gguf.hpp"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace fs = std::filesystem;

namespace luna::util {

bool probe_arch(const std::string& path, std::string& arch_out) {
  try {
    io::GgufFile f;
    if (!f.open(path)) return false;
    arch_out = f.arch();
    return true;
  } catch (...) {
    return false;
  }
}

bool is_supported_arch(const std::string& arch) {
  // Arquiteturas que o forward do Luna.cpp suporta hoje:
  static const char* kOk[] = {
    "llama", "qwen2", "qwen3", "mistral", "smollm2", "yi", "lfm2",
    "gemma2",
  };
  for (auto* k : kOk) if (arch == k) return true;
  return false;
}

namespace {

std::string home_dir() {
  const char* h = std::getenv("HOME");
  return h ? std::string(h) : std::string();
}

bool has_suffix_ci(const std::string& s, const std::string& suf) {
  if (s.size() < suf.size()) return false;
  for (size_t i = 0; i < suf.size(); ++i) {
    char a = (char)std::tolower((unsigned char)s[s.size() - suf.size() + i]);
    char b = (char)std::tolower((unsigned char)suf[i]);
    if (a != b) return false;
  }
  return true;
}

std::string to_lower(std::string s) {
  for (auto& c : s) c = (char)std::tolower((unsigned char)c);
  return s;
}

}  // namespace

std::vector<std::string> default_model_dirs() {
  const std::string H = home_dir();
  std::vector<std::string> dirs = {
    // Termux (Android)
    H + "/models",
    H + "/storage/downloads",
    H + "/storage/downloads/models",
    "/storage/emulated/0/Modelos llm",
    "/storage/emulated/0/Models",
    "/storage/emulated/0/Download",
    "/storage/emulated/0/Models llm",
    // Linux / macOS típicos
    H + "/.cache/luna/models",
    H + "/.local/share/luna/models",
    "/usr/local/share/luna/models",
    "/opt/luna/models",
  };
  return dirs;
}

void add_dirs_from_env(std::vector<std::string>& dirs) {
  const char* env = std::getenv("LUNA_MODEL_PATH");
  if (!env || !*env) return;
  std::string s(env);
  size_t start = 0;
  while (start < s.size()) {
    size_t sep = s.find(':', start);
    std::string part = (sep == std::string::npos)
                         ? s.substr(start)
                         : s.substr(start, sep - start);
    if (!part.empty()) dirs.push_back(part);
    if (sep == std::string::npos) break;
    start = sep + 1;
  }
}

std::vector<ModelEntry> list_models() {
  std::vector<ModelEntry> out;

  auto dirs = default_model_dirs();
  add_dirs_from_env(dirs);

  // dedup diretórios
  std::sort(dirs.begin(), dirs.end());
  dirs.erase(std::unique(dirs.begin(), dirs.end()), dirs.end());

  for (const auto& d : dirs) {
    std::error_code ec;
    if (!fs::is_directory(d, ec)) continue;

    // Busca recursiva com limite de profundidade 3
    for (auto it = fs::recursive_directory_iterator(
             d, fs::directory_options::skip_permission_denied, ec);
         it != fs::recursive_directory_iterator(); it.increment(ec)) {
      if (ec) break;
      if (it.depth() > 3) { it.disable_recursion_pending(); continue; }
      if (!it->is_regular_file(ec)) continue;

      const std::string p = it->path().string();
      if (!has_suffix_ci(p, ".gguf")) continue;

      ModelEntry e;
      e.name  = it->path().filename().string();
      e.path  = p;
      e.bytes = (uint64_t)fs::file_size(*it, ec);
      if (ec) e.bytes = 0;
      // Sondagem rápida: lê só o header do GGUF
      probe_arch(e.path, e.arch);
      e.supported = is_supported_arch(e.arch);
      out.push_back(std::move(e));
    }
  }

  // dedup por caminho e ordena por tamanho
  std::sort(out.begin(), out.end(),
            [](const ModelEntry& a, const ModelEntry& b) {
              return a.path < b.path;
            });
  out.erase(std::unique(out.begin(), out.end(),
                        [](const ModelEntry& a, const ModelEntry& b) {
                          return a.path == b.path;
                        }),
            out.end());

  std::sort(out.begin(), out.end(),
            [](const ModelEntry& a, const ModelEntry& b) {
              if (a.supported != b.supported) return a.supported > b.supported;
              if (a.bytes != b.bytes) return a.bytes < b.bytes;
              return a.name < b.name;
            });

  // Esconde arquiteturas não suportadas por padrão
  const char* show_all = std::getenv("LUNA_SHOW_ALL");
  if (!show_all || std::strcmp(show_all, "0") == 0) {
    out.erase(std::remove_if(out.begin(), out.end(),
                             [](const ModelEntry& e){ return !e.supported; }),
              out.end());
  }
  return out;
}

std::string resolve_model(const std::string& query) {
  if (query.empty()) return "";

  // 1) caminho direto?
  {
    std::error_code ec;
    if (fs::is_regular_file(query, ec)) return query;
  }

  // 2) procura nos diretórios padrão
  auto models = list_models();
  const std::string q = to_lower(query);

  // 2a) match exato por nome
  for (const auto& m : models)
    if (to_lower(m.name) == q) return m.path;

  // 2b) match exato ignorando .gguf
  std::string q_noext = q;
  if (has_suffix_ci(q_noext, ".gguf"))
    q_noext = q_noext.substr(0, q_noext.size() - 5);

  for (const auto& m : models) {
    std::string mn = to_lower(m.name);
    if (has_suffix_ci(mn, ".gguf"))
      mn = mn.substr(0, mn.size() - 5);
    if (mn == q_noext) return m.path;
  }

  // 3) match parcial: primeiro que contém
  for (const auto& m : models)
    if (to_lower(m.name).find(q_noext) != std::string::npos)
      return m.path;

  // 4) match parcial nos paths completos
  for (const auto& m : models)
    if (to_lower(m.path).find(q_noext) != std::string::npos)
      return m.path;

  return "";
}

std::string human_size(uint64_t bytes) {
  char buf[64];
  const char* u[] = {"B", "KB", "MB", "GB", "TB"};
  double b = (double)bytes;
  int i = 0;
  while (b >= 1024.0 && i < 4) { b /= 1024.0; ++i; }
  std::snprintf(buf, sizeof(buf), "%.1f %s", b, u[i]);
  return buf;
}

}  // namespace luna::util
