#include "tokenizer/chat.hpp"

#include <cstdio>

namespace luna::tokenizer {

const char* chat_format_name(ChatFormat f) {
  switch (f) {
    case ChatFormat::ChatML:  return "ChatML";
    case ChatFormat::Llama3:  return "Llama3";
    case ChatFormat::Mistral: return "Mistral";
    case ChatFormat::Phi3:    return "Phi3";
    case ChatFormat::Unknown: return "Unknown";
  }
  return "?";
}

void ChatTemplate::detect(io::GgufFile& file) {
  std::string tmpl;
  auto it = file.metadata.find("tokenizer.chat_template");
  if (it != file.metadata.end()) {
    if (auto* s = std::get_if<std::string>(&it->second)) tmpl = *s;
  }

  if (tmpl.find("<|im_start|>") != std::string::npos) {
    format = ChatFormat::ChatML;
    default_system = "You are a helpful AI assistant named SmolLM, trained by Hugging Face";
    return;
  }
  if (tmpl.find("<|start_header_id|>") != std::string::npos) {
    format = ChatFormat::Llama3;
    default_system = "You are a helpful assistant.";
    return;
  }
  if (tmpl.find("[INST]") != std::string::npos) {
    format = ChatFormat::Mistral;
    default_system = "";
    return;
  }
  if (tmpl.find("<|end|>") != std::string::npos &&
      tmpl.find("<|user|>") != std::string::npos) {
    format = ChatFormat::Phi3;
    default_system = "You are a helpful AI assistant.";
    return;
  }

  auto it_name = file.metadata.find("general.name");
  if (it_name != file.metadata.end()) {
    if (auto* s = std::get_if<std::string>(&it_name->second)) {
      if (s->find("Llama-3") != std::string::npos ||
          s->find("llama3") != std::string::npos) {
        format = ChatFormat::Llama3;
        default_system = "You are a helpful assistant.";
        return;
      }
      if (s->find("Mistral") != std::string::npos ||
          s->find("mistral") != std::string::npos) {
        format = ChatFormat::Mistral;
        default_system = "";
        return;
      }
    }
  }

  format = ChatFormat::ChatML;
  default_system = "You are a helpful assistant.";
}

namespace {

void push_encode(std::vector<int32_t>& ids, const BpeTokenizer& tk,
                 const std::string& text) {
  auto p = tk.encode(text, /*add_bos=*/false);
  ids.insert(ids.end(), p.begin(), p.end());
}

void push_special(std::vector<int32_t>& ids, const BpeTokenizer& tk,
                  const std::string& name) {
  int32_t id = tk.token_to_id(name);
  if (id < 0) {
    std::fprintf(stderr, "chat: token especial ausente: %s\n", name.c_str());
    return;
  }
  ids.push_back(id);
}

}  // namespace

std::vector<int32_t> ChatTemplate::build_prompt(const BpeTokenizer& tk,
                                                const std::string& system,
                                                const std::string& user) const {
  std::vector<int32_t> ids;

  switch (format) {
    case ChatFormat::ChatML: {
      const std::string sys = system.empty() ? default_system : system;
      if (!sys.empty()) {
        push_special(ids, tk, "<|im_start|>");
        push_encode (ids, tk, "system\n");
        push_encode (ids, tk, sys);
        push_special(ids, tk, "<|im_end|>");
        push_encode (ids, tk, "\n");
      }
      push_special(ids, tk, "<|im_start|>");
      push_encode (ids, tk, "user\n");
      push_encode (ids, tk, user);
      push_special(ids, tk, "<|im_end|>");
      push_encode (ids, tk, "\n");
      push_special(ids, tk, "<|im_start|>");
      push_encode (ids, tk, "assistant\n");
      break;
    }

    case ChatFormat::Llama3: {
      push_special(ids, tk, "<|begin_of_text|>");
      if (!system.empty()) {
        push_special(ids, tk, "<|start_header_id|>");
        push_encode (ids, tk, "system");
        push_special(ids, tk, "<|end_header_id|>");
        push_encode (ids, tk, "\n\n");
        push_encode (ids, tk, system);
        push_special(ids, tk, "<|eot_id|>");
      }
      push_special(ids, tk, "<|start_header_id|>");
      push_encode (ids, tk, "user");
      push_special(ids, tk, "<|end_header_id|>");
      push_encode (ids, tk, "\n\n");
      push_encode (ids, tk, user);
      push_special(ids, tk, "<|eot_id|>");
      push_special(ids, tk, "<|start_header_id|>");
      push_encode (ids, tk, "assistant");
      push_special(ids, tk, "<|end_header_id|>");
      push_encode (ids, tk, "\n\n");
      break;
    }

    case ChatFormat::Mistral: {
      push_special(ids, tk, "<s>");
      push_encode (ids, tk, "[INST] ");
      if (!system.empty()) push_encode(ids, tk, system + "\n\n");
      push_encode (ids, tk, user);
      push_encode (ids, tk, " [/INST]");
      break;
    }

    case ChatFormat::Phi3: {
      if (!system.empty()) {
        push_special(ids, tk, "<|system|>");
        push_encode (ids, tk, "\n");
        push_encode (ids, tk, system);
        push_special(ids, tk, "<|end|>");
        push_encode (ids, tk, "\n");
      }
      push_special(ids, tk, "<|user|>");
      push_encode (ids, tk, "\n");
      push_encode (ids, tk, user);
      push_special(ids, tk, "<|end|>");
      push_encode (ids, tk, "\n");
      push_special(ids, tk, "<|assistant|>");
      push_encode (ids, tk, "\n");
      break;
    }

    case ChatFormat::Unknown:
      push_encode(ids, tk, user);
      break;
  }
  return ids;
}

std::vector<int32_t> ChatTemplate::next_turn(const BpeTokenizer& tk,
                                             const std::string& user) const {
  std::vector<int32_t> ids;

  switch (format) {
    case ChatFormat::ChatML: {
      push_encode (ids, tk, "\n");
      push_special(ids, tk, "<|im_start|>");
      push_encode (ids, tk, "user\n");
      push_encode (ids, tk, user);
      push_special(ids, tk, "<|im_end|>");
      push_encode (ids, tk, "\n");
      push_special(ids, tk, "<|im_start|>");
      push_encode (ids, tk, "assistant\n");
      break;
    }

    case ChatFormat::Llama3: {
      push_special(ids, tk, "<|start_header_id|>");
      push_encode (ids, tk, "user");
      push_special(ids, tk, "<|end_header_id|>");
      push_encode (ids, tk, "\n\n");
      push_encode (ids, tk, user);
      push_special(ids, tk, "<|eot_id|>");
      push_special(ids, tk, "<|start_header_id|>");
      push_encode (ids, tk, "assistant");
      push_special(ids, tk, "<|end_header_id|>");
      push_encode (ids, tk, "\n\n");
      break;
    }

    case ChatFormat::Mistral: {
      push_encode (ids, tk, " [INST] ");
      push_encode (ids, tk, user);
      push_encode (ids, tk, " [/INST]");
      break;
    }

    case ChatFormat::Phi3: {
      push_encode (ids, tk, "\n");
      push_special(ids, tk, "<|user|>");
      push_encode (ids, tk, "\n");
      push_encode (ids, tk, user);
      push_special(ids, tk, "<|end|>");
      push_encode (ids, tk, "\n");
      push_special(ids, tk, "<|assistant|>");
      push_encode (ids, tk, "\n");
      break;
    }

    case ChatFormat::Unknown:
      push_encode(ids, tk, user);
      break;
  }
  return ids;
}

std::vector<int32_t> ChatTemplate::stop_ids(const BpeTokenizer& tk) const {
  std::vector<int32_t> out;
  auto add = [&](const char* name) {
    int32_t id = tk.token_to_id(name);
    if (id >= 0) out.push_back(id);
  };
  switch (format) {
    case ChatFormat::ChatML:
      add("<|im_end|>");
      add("<|endoftext|>");
      break;
    case ChatFormat::Llama3:
      add("<|eot_id|>");
      add("<|end_of_text|>");
      break;
    case ChatFormat::Mistral:
      add("</s>");
      break;
    case ChatFormat::Phi3:
      add("<|end|>");
      add("<|endoftext|>");
      break;
    case ChatFormat::Unknown:
      break;
  }
  out.push_back(tk.eos_id());
  return out;
}

}  // namespace luna::tokenizer
