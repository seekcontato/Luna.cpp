#include "tokenizer/bpe.hpp"

#include <algorithm>
#include <climits>
#include <stdexcept>

namespace luna::tokenizer {

void BpeTokenizer::build_byte_to_unicode() {
  auto in_range = [](int b, int lo, int hi) { return b >= lo && b <= hi; };

  std::vector<int> bs, cs;
  for (int b = 0; b < 256; ++b) {
    if (in_range(b, '!', '~') || in_range(b, 0xA1, 0xAC) ||
        in_range(b, 0xAE, 0xFF)) {
      bs.push_back(b);
      cs.push_back(b);
    }
  }
  int n = 0;
  for (int b = 0; b < 256; ++b) {
    if (in_range(b, '!', '~') || in_range(b, 0xA1, 0xAC) ||
        in_range(b, 0xAE, 0xFF)) continue;
    bs.push_back(b);
    cs.push_back(256 + n);
    ++n;
  }

  for (size_t i = 0; i < bs.size(); ++i) {
    int cp = cs[i];
    std::string utf8;
    if (cp < 0x80) {
      utf8.push_back((char)cp);
    } else if (cp < 0x800) {
      utf8.push_back((char)(0xC0 | (cp >> 6)));
      utf8.push_back((char)(0x80 | (cp & 0x3F)));
    } else {
      utf8.push_back((char)(0xE0 | (cp >> 12)));
      utf8.push_back((char)(0x80 | ((cp >> 6) & 0x3F)));
      utf8.push_back((char)(0x80 | (cp & 0x3F)));
    }
    byte_to_unicode_[(uint8_t)bs[i]] = utf8;
  }
}

std::string BpeTokenizer::bytes_to_unicode_str(const std::string& s) const {
  std::string out;
  for (unsigned char c : s) {
    auto it = byte_to_unicode_.find(c);
    if (it != byte_to_unicode_.end()) out += it->second;
    else out.push_back((char)c);
  }
  return out;
}

std::string BpeTokenizer::unicode_to_bytes_str(const std::string& s) const {
  std::unordered_map<std::string, uint8_t> rev;
  for (auto& kv : byte_to_unicode_) rev[kv.second] = kv.first;

  std::string out;
  size_t i = 0;
  while (i < s.size()) {
    bool matched = false;
    for (size_t len = 1; len <= 3 && i + len <= s.size(); ++len) {
      std::string sub = s.substr(i, len);
      auto it = rev.find(sub);
      if (it != rev.end()) {
        out.push_back((char)it->second);
        i += len;
        matched = true;
        break;
      }
    }
    if (!matched) {
      out.push_back(s[i]);
      ++i;
    }
  }
  return out;
}

bool BpeTokenizer::load(io::GgufFile& file) {
  build_byte_to_unicode();

  auto it_tok = file.metadata.find("tokenizer.ggml.tokens");
  if (it_tok == file.metadata.end())
    throw std::runtime_error("tokenizer: tokenizer.ggml.tokens ausente");

  auto* toks = std::get_if<std::vector<std::string>>(&it_tok->second);
  if (!toks)
    throw std::runtime_error("tokenizer: tokens em formato inesperado");

  id_to_token_ = *toks;
  for (size_t i = 0; i < id_to_token_.size(); ++i)
    token_to_id_[id_to_token_[i]] = (int32_t)i;

  auto it_mrg = file.metadata.find("tokenizer.ggml.merges");
  if (it_mrg != file.metadata.end()) {
    if (auto* m = std::get_if<std::vector<std::string>>(&it_mrg->second)) {
      merges_.reserve(m->size());
      for (size_t i = 0; i < m->size(); ++i) {
        const std::string& line = (*m)[i];
        auto sp = line.find(' ');
        if (sp == std::string::npos) continue;
        std::string a = line.substr(0, sp);
        std::string b = line.substr(sp + 1);
        merges_.emplace_back(a, b);
        merge_rank_[a + "\x1F" + b] = (int32_t)i;
      }
    }
  }

  auto get_id = [&](const char* key, int32_t fallback) {
    auto it = file.metadata.find(key);
    if (it == file.metadata.end()) return fallback;
    if (auto* v = std::get_if<uint32_t>(&it->second)) return (int32_t)*v;
    if (auto* v = std::get_if<int32_t>(&it->second))  return *v;
    return fallback;
  };
  bos_id_ = get_id("tokenizer.ggml.bos_token_id", bos_id_);
  eos_id_ = get_id("tokenizer.ggml.eos_token_id", eos_id_);

  auto it_ab = file.metadata.find("tokenizer.ggml.add_bos_token");
  if (it_ab != file.metadata.end()) {
    if (auto* b = std::get_if<bool>(&it_ab->second)) add_bos_ = *b;
  }

  return !id_to_token_.empty();
}

int32_t BpeTokenizer::token_to_id(const std::string& s) const {
  auto it = token_to_id_.find(s);
  return it == token_to_id_.end() ? -1 : it->second;
}

std::vector<int32_t> BpeTokenizer::encode(const std::string& text,
                                          bool add_bos) const {
  std::vector<int32_t> ids;
  if (add_bos) ids.push_back(bos_id_);

  if (merges_.empty()) {
    for (unsigned char c : text) {
      std::string u = bytes_to_unicode_str(std::string(1, (char)c));
      auto it = token_to_id_.find(u);
      if (it != token_to_id_.end()) ids.push_back(it->second);
    }
    return ids;
  }

  std::vector<std::string> symbols;
  for (unsigned char c : text) {
    symbols.push_back(byte_to_unicode_.at(c));
  }

  while (symbols.size() > 1) {
    int32_t best_rank = INT32_MAX;
    size_t  best_i    = SIZE_MAX;
    for (size_t i = 0; i + 1 < symbols.size(); ++i) {
      std::string key = symbols[i] + "\x1F" + symbols[i + 1];
      auto it = merge_rank_.find(key);
      if (it != merge_rank_.end() && it->second < best_rank) {
        best_rank = it->second;
        best_i    = i;
      }
    }
    if (best_i == SIZE_MAX) break;
    symbols[best_i] = symbols[best_i] + symbols[best_i + 1];
    symbols.erase(symbols.begin() + best_i + 1);
  }

  for (const auto& s : symbols) {
    auto it = token_to_id_.find(s);
    if (it != token_to_id_.end()) ids.push_back(it->second);
    else {
      for (unsigned char c : unicode_to_bytes_str(s)) {
        std::string u = bytes_to_unicode_str(std::string(1, (char)c));
        auto it2 = token_to_id_.find(u);
        if (it2 != token_to_id_.end()) ids.push_back(it2->second);
      }
    }
  }
  return ids;
}

std::string BpeTokenizer::decode(const std::vector<int32_t>& ids) const {
  std::string out;
  for (auto id : ids) out += decode_one(id);
  return out;
}

std::string BpeTokenizer::decode_one(int32_t id) const {
  if (id < 0 || (size_t)id >= id_to_token_.size()) return "";
  const std::string& tok = id_to_token_[(size_t)id];
  // Tokens especiais (começam com "<|" e terminam com "|>") saem literais
  if (tok.size() >= 4 && tok.compare(0, 2, "<|") == 0 &&
      tok.compare(tok.size() - 2, 2, "|>") == 0) {
    return tok;
  }
  return unicode_to_bytes_str(tok);
}

}  // namespace luna::tokenizer
