#pragma once

#include "io/gguf.hpp"
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace luna::tokenizer {

class BpeTokenizer {
 public:
  bool load(io::GgufFile& file);

  // encode com BOS conforme configuração do GGUF
  std::vector<int32_t> encode(const std::string& text) const {
    return encode(text, add_bos_);
  }
  // encode com controle explícito de BOS
  std::vector<int32_t> encode(const std::string& text, bool add_bos) const;

  std::string decode(const std::vector<int32_t>& ids) const;
  std::string decode_one(int32_t id) const;

  // ID de um token especial (ex: "<|im_start|>"). -1 se não existir.
  int32_t token_to_id(const std::string& s) const;

  size_t vocab_size() const { return id_to_token_.size(); }

  int32_t bos_id()  const { return bos_id_; }
  int32_t eos_id()  const { return eos_id_; }
  bool    add_bos() const { return add_bos_; }

 private:
  std::vector<std::string> id_to_token_;
  std::unordered_map<std::string, int32_t> token_to_id_;
  std::vector<std::pair<std::string, std::string>> merges_;
  std::unordered_map<std::string, int32_t> merge_rank_;

  int32_t bos_id_  = 1;
  int32_t eos_id_  = 2;
  bool    add_bos_ = true;

  std::unordered_map<uint8_t, std::string> byte_to_unicode_;
  void build_byte_to_unicode();
  std::string bytes_to_unicode_str(const std::string& s) const;
  std::string unicode_to_bytes_str(const std::string& s) const;
};

}  // namespace luna::tokenizer
