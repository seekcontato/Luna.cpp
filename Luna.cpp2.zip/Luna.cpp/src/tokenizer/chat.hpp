#pragma once

#include "io/gguf.hpp"
#include "tokenizer/bpe.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace luna::tokenizer {

enum class ChatFormat {
  ChatML,
  Llama3,
  Mistral,
  Phi3,
  Unknown,
};

const char* chat_format_name(ChatFormat f);

class ChatTemplate {
 public:
  ChatFormat  format = ChatFormat::ChatML;
  std::string default_system;

  void detect(io::GgufFile& file);

  // Primeiro turno: inclui system block + user + assistant marker
  std::vector<int32_t> build_prompt(const BpeTokenizer& tk,
                                    const std::string& system,
                                    const std::string& user) const;

  // Turnos seguintes: continua após o <|im_end|> do assistant anterior
  std::vector<int32_t> next_turn(const BpeTokenizer& tk,
                                 const std::string& user) const;

  std::vector<int32_t> stop_ids(const BpeTokenizer& tk) const;
};

}  // namespace luna::tokenizer
