#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <csignal>
#include <unistd.h>
#include <string>
#include <vector>

#include "luna/luna.hpp"
#include "core/tensor.hpp"
#include "io/gguf.hpp"
#include "models/llama.hpp"
#include "models/llama_weights.hpp"
#include "models/forward.hpp"
#include "tokenizer/bpe.hpp"
#include "tokenizer/chat.hpp"
#include "util/model_finder.hpp"
#include "util/selector.hpp"

static void on_signal(int) { _exit(130); }

static void usage(const char* a) {
  std::printf("Luna.cpp v%s\n", luna::version());
  std::printf("Uso:\n");
  std::printf("  %s pick                    abre o seletor de modelos\n", a);
  std::printf("  %s list                    lista modelos encontrados\n", a);
  std::printf("  %s find    <query>         busca por nome parcial\n", a);
  std::printf("  %s selftest\n", a);
  std::printf("  %s info    <modelo>        mostra info do GGUF\n", a);
  std::printf("  %s tensors <modelo>        lista tensores\n", a);
  std::printf("  %s tok     <modelo> \"txt\"\n", a);
  std::printf("\nUse `luna-chat` para conversar. Ex:\n");
  std::printf("  luna-chat                    (abre seletor)\n");
  std::printf("  luna-chat qwen2.5-0.5b\n");
}

static int cmd_list() {
  auto models = luna::util::list_models();
  if (models.empty()) {
    std::printf("Nenhum .gguf encontrado.\n");
    std::printf("Diretórios procurados:\n");
    for (const auto& d : luna::util::default_model_dirs())
      std::printf("  %s\n", d.c_str());
    return 1;
  }

  std::printf("%-8s %s\n", "TAMANHO", "CAMINHO");
  std::printf("%-8s %s\n", "-------", "------");
  for (const auto& m : models)
    std::printf("%-8s %s\n", luna::util::human_size(m.bytes).c_str(),
                m.path.c_str());
  std::printf("\n%zu modelo(s)\n", models.size());
  return 0;
}

static int cmd_find(const std::string& query) {
  auto models = luna::util::list_models();
  int shown = 0;
  std::printf("Procurando \"%s\"...\n\n", query.c_str());
  for (const auto& m : models) {
    if (m.name.find(query) != std::string::npos ||
        m.path.find(query) != std::string::npos) {
      std::printf("  %-8s %s\n",
                  luna::util::human_size(m.bytes).c_str(), m.path.c_str());
      ++shown;
    }
  }
  if (shown == 0) { std::printf("Nada encontrado.\n"); return 1; }
  std::string best = luna::util::resolve_model(query);
  if (!best.empty()) std::printf("\nMelhor match: %s\n", best.c_str());
  return 0;
}

static int cmd_pick() {
  auto models = luna::util::list_models();
  if (models.empty()) {
    std::fprintf(stderr, "Nenhum .gguf encontrado nos diretórios padrão.\n");
    for (const auto& d : luna::util::default_model_dirs())
      std::fprintf(stderr, "  %s\n", d.c_str());
    return 1;
  }
  std::string p = luna::util::pick_model(models, "Luna.cpp — escolha um modelo");
  if (p.empty()) { std::printf("Cancelado.\n"); return 1; }
  std::printf("%s\n", p.c_str());
  return 0;
}

static int selftest() {
  using namespace luna::core;
  auto t = zeros({2, 3});
  t.at({0, 0}) = 1.0f;
  t.at({1, 2}) = 2.5f;
  std::printf("[core] %s\n", t.repr().c_str());
  std::printf("[core] min=%.3f max=%.3f mean=%.3f l2=%.3f\n",
              t.min(), t.max(), t.mean(), t.l2norm());
  std::printf("selftest OK\n");
  return 0;
}

// Se input não resolver, tenta pelo seletor interativo.
static std::string resolve_with_fallback(const std::string& input) {
  if (input.empty()) {
    auto models = luna::util::list_models();
    if (models.empty()) {
      std::fprintf(stderr, "Nenhum modelo encontrado. Veja `luna-cli list`.\n");
      std::exit(2);
    }
    std::string p = luna::util::pick_model(models, "Escolha um modelo");
    if (p.empty()) { std::fprintf(stderr, "Cancelado.\n"); std::exit(1); }
    return p;
  }
  std::string p = luna::util::resolve_model(input);
  if (!p.empty()) {
    if (p != input) std::printf("[finder] %s -> %s\n", input.c_str(), p.c_str());
    return p;
  }
  // Não achou — abre o seletor como fallback
  auto models = luna::util::list_models();
  if (models.empty()) {
    std::fprintf(stderr, "erro: não encontrei \"%s\".\n", input.c_str());
    std::exit(2);
  }
  std::fprintf(stderr, "Não encontrei \"%s\". Escolha um:\n", input.c_str());
  std::string chosen = luna::util::pick_model(models, "Escolha um modelo");
  if (chosen.empty()) { std::fprintf(stderr, "Cancelado.\n"); std::exit(1); }
  return chosen;
}

static std::vector<int32_t> parse_tokens(const char* s) {
  std::vector<int32_t> out;
  const char* p = s;
  while (*p) {
    char* end = nullptr;
    long v = std::strtol(p, &end, 10);
    if (end == p) break;
    out.push_back((int32_t)v);
    p = end;
    if (*p == ',') ++p;
  }
  return out;
}

static int cmd_tok(const std::string& path, const std::string& text) {
  luna::io::GgufFile file;
  if (!file.open(path)) { std::fprintf(stderr, "erro abrindo %s\n", path.c_str()); return 2; }
  luna::tokenizer::BpeTokenizer tk;
  try { tk.load(file); }
  catch (const std::exception& e) { std::fprintf(stderr, "tokenizer: %s\n", e.what()); return 3; }
  auto ids = tk.encode(text);
  std::printf("texto : \"%s\"\n", text.c_str());
  std::printf("ids   : ");
  for (auto id : ids) std::printf("%d ", id);
  std::printf("\n");
  std::printf("decode: \"%s\"\n", tk.decode(ids).c_str());
  return 0;
}

int main(int argc, char** argv) {
  std::signal(SIGINT,  on_signal);
  std::signal(SIGTERM, on_signal);
  if (argc < 2) { usage(argv[0]); return 1; }
  std::string cmd = argv[1];

  if (cmd == "selftest") return selftest();
  if (cmd == "list")     return cmd_list();
  if (cmd == "pick")     return cmd_pick();
  if (cmd == "find") {
    if (argc < 3) { std::fprintf(stderr, "find: falta <query>\n"); return 2; }
    return cmd_find(argv[2]);
  }

  if (argc < 3) { usage(argv[0]); return 1; }
  std::string path = resolve_with_fallback(argv[2]);

  if (cmd == "tok") {
    if (argc < 4) { std::fprintf(stderr, "tok: falta texto\n"); return 2; }
    return cmd_tok(path, argv[3]);
  }

  luna::io::GgufFile file;
  if (!file.open(path)) { std::fprintf(stderr, "erro abrindo %s\n", path.c_str()); return 2; }

  if (cmd == "info") {
    std::printf("Arquivo   : %s\n", path.c_str());
    std::printf("Versão    : %u\n", file.version);
    std::printf("Alignment : %llu\n", (unsigned long long)file.alignment);
    std::printf("Metadata  : %zu chaves\n", file.metadata.size());
    std::printf("Tensores  : %zu\n", file.tensors.size());

    luna::models::LlamaModel model;
    if (model.load(file)) { std::printf("\n"); model.print_summary(); }
    return 0;
  }

  if (cmd == "tensors") {
    for (const auto& t : file.tensors) {
      std::printf("%-40s %-6s [", t.name.c_str(),
                  luna::io::ggml_type_name(t.type));
      for (size_t i = 0; i < t.shape.size(); ++i) {
        std::printf("%llu%s", (unsigned long long)t.shape[i],
                    i + 1 < t.shape.size() ? ", " : "");
      }
      std::printf("]\n");
    }
    return 0;
  }

  usage(argv[0]);
  return 1;
}
