#include "io/gguf.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <stdexcept>

namespace luna::io {

const char* ggml_type_name(GgmlType t) {
  switch (t) {
    case GgmlType::F32: return "F32"; case GgmlType::F16: return "F16";
    case GgmlType::Q4_0: return "Q4_0"; case GgmlType::Q4_1: return "Q4_1";
    case GgmlType::Q5_0: return "Q5_0"; case GgmlType::Q5_1: return "Q5_1";
    case GgmlType::Q8_0: return "Q8_0"; case GgmlType::Q8_1: return "Q8_1";
    case GgmlType::Q2_K: return "Q2_K"; case GgmlType::Q3_K: return "Q3_K";
    case GgmlType::Q4_K: return "Q4_K"; case GgmlType::Q5_K: return "Q5_K";
    case GgmlType::Q6_K: return "Q6_K"; case GgmlType::Q8_K: return "Q8_K";
    case GgmlType::BF16: return "BF16";
  }
  return "UNKNOWN";
}

size_t ggml_block_size(GgmlType t) {
  switch (t) {
    case GgmlType::F32: case GgmlType::F16: case GgmlType::BF16: return 1;
    case GgmlType::Q4_0: case GgmlType::Q4_1:
    case GgmlType::Q5_0: case GgmlType::Q5_1:
    case GgmlType::Q8_0: case GgmlType::Q8_1: return 32;
    default: return 256;
  }
}

size_t ggml_type_size(GgmlType t) {
  switch (t) {
    case GgmlType::F32: return 4; case GgmlType::F16: return 2;
    case GgmlType::BF16: return 2;
    case GgmlType::Q4_0: return 18; case GgmlType::Q4_1: return 20;
    case GgmlType::Q5_0: return 22; case GgmlType::Q5_1: return 24;
    case GgmlType::Q8_0: return 34; case GgmlType::Q8_1: return 36;
    case GgmlType::Q2_K: return 84; case GgmlType::Q3_K: return 110;
    case GgmlType::Q4_K: return 144; case GgmlType::Q5_K: return 176;
    case GgmlType::Q6_K: return 210; default: return 0;
  }
}

namespace {

template <typename T> T read_pod(std::ifstream& f) {
  T v{}; f.read(reinterpret_cast<char*>(&v), sizeof(T));
  if (!f) throw std::runtime_error("GGUF: leitura falhou"); return v;
}
std::string read_string(std::ifstream& f) {
  uint64_t n = read_pod<uint64_t>(f);
  std::string s(n, '\0');
  f.read(s.data(), static_cast<std::streamsize>(n));
  if (!f) throw std::runtime_error("GGUF: string falhou"); return s;
}
MetaValue read_value(std::ifstream& f, uint32_t type);
MetaValue read_array(std::ifstream& f) {
  uint32_t et = read_pod<uint32_t>(f); uint64_t n = read_pod<uint64_t>(f);
  if (et == 8) { std::vector<std::string> v; v.reserve(n);
    for (uint64_t i=0;i<n;++i) v.push_back(read_string(f)); return v; }
  if (et == 5) { std::vector<int32_t> v(n);
    f.read(reinterpret_cast<char*>(v.data()), (std::streamsize)(n*4)); return v; }
  if (et == 6) { std::vector<float> v(n);
    f.read(reinterpret_cast<char*>(v.data()), (std::streamsize)(n*4)); return v; }
  for (uint64_t i=0;i<n;++i) read_value(f, et);
  return std::string{"<ignorado>"};
}
MetaValue read_value(std::ifstream& f, uint32_t type) {
  switch (type) {
    case 0: return read_pod<uint8_t>(f);   case 1: return read_pod<int8_t>(f);
    case 2: return read_pod<uint16_t>(f);  case 3: return read_pod<int16_t>(f);
    case 4: return read_pod<uint32_t>(f);  case 5: return read_pod<int32_t>(f);
    case 6: return read_pod<float>(f);     case 7: return read_pod<uint8_t>(f) != 0;
    case 8: return read_string(f);         case 9: return read_array(f);
    case 10: return read_pod<uint64_t>(f); case 11: return read_pod<int64_t>(f);
    case 12: return read_pod<double>(f);
    default: throw std::runtime_error("GGUF: tipo desconhecido");
  }
}

inline int nib_lo(uint8_t b) { return b & 0xF; }
inline int nib_hi(uint8_t b) { return b >> 4; }

void dq_q4_0(const uint8_t* p, float* y, size_t n) {
  for (size_t i=0;i<n/32;++i) {
    const uint8_t* b = p + i*18;
    uint16_t dh; std::memcpy(&dh,b,2); float d = fp16_to_fp32(dh);
    const uint8_t* qs = b + 2; float* yy = y + i*32;
    for (int j=0;j<16;++j) { yy[j]=(float)(nib_lo(qs[j])-8)*d; yy[j+16]=(float)(nib_hi(qs[j])-8)*d; }
  }
}
void dq_q4_1(const uint8_t* p, float* y, size_t n) {
  for (size_t i=0;i<n/32;++i) {
    const uint8_t* b=p+i*20;
    uint16_t dh,mh; std::memcpy(&dh,b,2); std::memcpy(&mh,b+2,2);
    float d=fp16_to_fp32(dh), m=fp16_to_fp32(mh);
    const uint8_t* qs=b+4; float* yy=y+i*32;
    for (int j=0;j<16;++j) { yy[j]=(float)nib_lo(qs[j])*d+m; yy[j+16]=(float)nib_hi(qs[j])*d+m; }
  }
}
void dq_q5_0(const uint8_t* p, float* y, size_t n) {
  for (size_t i=0;i<n/32;++i) {
    const uint8_t* b=p+i*22;
    uint16_t dh; std::memcpy(&dh,b,2); float d=fp16_to_fp32(dh);
    uint32_t qh; std::memcpy(&qh,b+2,4);
    const uint8_t* qs=b+6; float* yy=y+i*32;
    for (int j=0;j<16;++j) {
      uint8_t xh0=(uint8_t)(((qh>>(j+0))<<4)&0x10);
      uint8_t xh1=(uint8_t)(((qh>>(j+12)))&0x10);
      yy[j]=(float)((nib_lo(qs[j])|xh0)-16)*d;
      yy[j+16]=(float)((nib_hi(qs[j])|xh1)-16)*d;
    }
  }
}
void dq_q5_1(const uint8_t* p, float* y, size_t n) {
  for (size_t i=0;i<n/32;++i) {
    const uint8_t* b=p+i*24;
    uint16_t dh,mh; std::memcpy(&dh,b,2); std::memcpy(&mh,b+2,2);
    float d=fp16_to_fp32(dh), m=fp16_to_fp32(mh);
    uint32_t qh; std::memcpy(&qh,b+4,4);
    const uint8_t* qs=b+8; float* yy=y+i*32;
    for (int j=0;j<16;++j) {
      uint8_t xh0=(uint8_t)(((qh>>(j+0))<<4)&0x10);
      uint8_t xh1=(uint8_t)(((qh>>(j+12)))&0x10);
      yy[j]=(float)(nib_lo(qs[j])|xh0)*d+m;
      yy[j+16]=(float)(nib_hi(qs[j])|xh1)*d+m;
    }
  }
}
void dq_q8_0(const uint8_t* p, float* y, size_t n) {
  for (size_t i=0;i<n/32;++i) {
    const uint8_t* b=p+i*34;
    uint16_t dh; std::memcpy(&dh,b,2); float d=fp16_to_fp32(dh);
    const int8_t* qs=(const int8_t*)(b+2); float* yy=y+i*32;
    for (int j=0;j<32;++j) yy[j]=(float)qs[j]*d;
  }
}

inline void get_scale_min_k4(int j, const uint8_t* q, uint8_t* d, uint8_t* m) {
  if (j<4) { *d=q[j]&63; *m=q[j+4]&63; }
  else { *d=(q[j+4]&0xF)|((q[j-4]>>6)<<4); *m=(q[j+4]>>4)|((q[j]>>6)<<4); }
}
void dq_q4_K(const uint8_t* p, float* y, size_t n) {
  for (size_t i=0;i<n/256;++i) {
    const uint8_t* b=p+i*144;
    uint16_t dh,dmh; std::memcpy(&dh,b,2); std::memcpy(&dmh,b+2,2);
    float d=fp16_to_fp32(dh), dmin=fp16_to_fp32(dmh);
    const uint8_t* sc=b+4; const uint8_t* qs=b+16;
    int is=0; float* yy=y+i*256;
    for (int j=0;j<256;j+=64) {
      uint8_t s1,m1,s2,m2;
      get_scale_min_k4(is+0,sc,&s1,&m1);
      get_scale_min_k4(is+1,sc,&s2,&m2);
      float d1=d*s1, m1f=dmin*m1, d2=d*s2, m2f=dmin*m2;
      for (int l=0;l<32;++l) yy[l]     = d1*(qs[l]&0xF) - m1f;
      for (int l=0;l<32;++l) yy[l+32]  = d2*(qs[l]>>4)  - m2f;
      yy+=64; qs+=32; is+=2;
    }
  }
}
void dq_q6_K(const uint8_t* p, float* y, size_t n) {
  for (size_t i=0;i<n/256;++i) {
    const uint8_t* b=p+i*210;
    const uint8_t* ql=b; const uint8_t* qh=b+128;
    const int8_t* sc=(const int8_t*)(b+192);
    uint16_t dh; std::memcpy(&dh,b+208,2); float d=fp16_to_fp32(dh);
    float* yy=y+i*256;
    for (int off=0;off<256;off+=128) {
      for (int l=0;l<32;++l) {
        int is=l/16;
        int8_t q1=(int8_t)((ql[l]&0xF)|(((qh[l]>>0)&3)<<4))-32;
        int8_t q2=(int8_t)((ql[l+32]&0xF)|(((qh[l]>>2)&3)<<4))-32;
        int8_t q3=(int8_t)((ql[l]>>4)|(((qh[l]>>4)&3)<<4))-32;
        int8_t q4=(int8_t)((ql[l+32]>>4)|(((qh[l]>>6)&3)<<4))-32;
        yy[l]=d*sc[is+0]*q1; yy[l+32]=d*sc[is+2]*q2;
        yy[l+64]=d*sc[is+4]*q3; yy[l+96]=d*sc[is+6]*q4;
      }
      yy+=128; ql+=64; qh+=32; sc+=8;
    }
  }
}

}  // namespace

// Dispatch global (usado por read_f16)
void luna_dq_dispatch(GgmlType t, const uint8_t* p, float* y, size_t n) {
  switch (t) {
    case GgmlType::Q4_0: dq_q4_0(p,y,n); break;
    case GgmlType::Q4_1: dq_q4_1(p,y,n); break;
    case GgmlType::Q5_0: dq_q5_0(p,y,n); break;
    case GgmlType::Q5_1: dq_q5_1(p,y,n); break;
    case GgmlType::Q8_0: dq_q8_0(p,y,n); break;
    case GgmlType::Q4_K: dq_q4_K(p,y,n); break;
    case GgmlType::Q6_K: dq_q6_K(p,y,n); break;
    default: throw std::runtime_error("dequant não implementada");
  }
}

bool GgufFile::open(const std::string& path) {
  stream.open(path, std::ios::binary);
  if (!stream) return false;
  char magic[4]; stream.read(magic, 4);
  if (std::strncmp(magic, "GGUF", 4) != 0) return false;
  version = read_pod<uint32_t>(stream);
  if (version < 2) throw std::runtime_error("GGUF: só v2/v3");
  uint64_t tc = read_pod<uint64_t>(stream);
  uint64_t kc = read_pod<uint64_t>(stream);
  for (uint64_t i=0;i<kc;++i) {
    std::string k = read_string(stream);
    uint32_t vt = read_pod<uint32_t>(stream);
    metadata.emplace(std::move(k), read_value(stream, vt));
  }
  if (auto it = metadata.find("general.alignment"); it != metadata.end()) {
    if (auto p = std::get_if<uint32_t>(&it->second)) alignment = *p;
    else if (auto p = std::get_if<uint64_t>(&it->second)) alignment = *p;
  }
  tensors.reserve(tc);
  for (uint64_t i=0;i<tc;++i) {
    TensorInfo info;
    info.name = read_string(stream);
    uint32_t nd = read_pod<uint32_t>(stream);
    info.shape.resize(nd);
    for (uint32_t d=0;d<nd;++d) info.shape[d] = read_pod<uint64_t>(stream);
    info.type = static_cast<GgmlType>(read_pod<uint32_t>(stream));
    info.offset = read_pod<uint64_t>(stream);
    tensor_index[info.name] = tensors.size();
    tensors.push_back(std::move(info));
  }
  uint64_t pos = (uint64_t)stream.tellg();
  data_offset = ((pos + alignment - 1) / alignment) * alignment;
  return true;
}

std::string GgufFile::arch() const {
  auto it = metadata.find("general.architecture");
  if (it == metadata.end()) return "llama";
  if (auto* s = std::get_if<std::string>(&it->second)) return *s;
  return "llama";
}

const TensorInfo* GgufFile::find(const std::string& name) const {
  auto it = tensor_index.find(name);
  if (it == tensor_index.end()) return nullptr;
  return &tensors[it->second];
}

std::vector<float> GgufFile::read_f32(const TensorInfo& info) {
  size_t n = 1; for (auto d : info.shape) n *= d;
  stream.seekg((std::streamoff)(data_offset + info.offset));
  std::vector<float> out(n);
  if (info.type == GgmlType::F32) {
    stream.read((char*)out.data(), (std::streamsize)(n*4));
  } else if (info.type == GgmlType::F16) {
    std::vector<uint16_t> raw(n);
    stream.read((char*)raw.data(), (std::streamsize)(n*2));
    for (size_t i=0;i<n;++i) out[i] = fp16_to_fp32(raw[i]);
  } else {
    const size_t bs = ggml_block_size(info.type);
    const size_t ts = ggml_type_size(info.type);
    if (bs == 0 || ts == 0 || n % bs != 0) throw std::runtime_error("read_f32: tipo inválido");
    std::vector<uint8_t> raw((n/bs)*ts);
    stream.read((char*)raw.data(), (std::streamsize)raw.size());
    luna_dq_dispatch(info.type, raw.data(), out.data(), n);
  }
  return out;
}

std::vector<uint16_t> GgufFile::read_f16(const TensorInfo& info) {
  size_t n = 1; for (auto d : info.shape) n *= d;
  stream.seekg((std::streamoff)(data_offset + info.offset));
  std::vector<uint16_t> out(n);
  if (info.type == GgmlType::F16) {
    stream.read((char*)out.data(), (std::streamsize)(n*2));
    return out;
  }
  if (info.type == GgmlType::F32) {
    const size_t CH = 1<<20;
    std::vector<float> tmp(std::min(CH, n));
    size_t done = 0;
    while (done < n) {
      size_t k = std::min(CH, n - done);
      stream.read((char*)tmp.data(), (std::streamsize)(k*4));
      for (size_t i=0;i<k;++i) out[done+i] = fp32_to_fp16(tmp[i]);
      done += k;
    }
    return out;
  }
  const size_t bs = ggml_block_size(info.type);
  const size_t ts = ggml_type_size(info.type);
  if (bs == 0 || ts == 0 || n % bs != 0) throw std::runtime_error("read_f16: tipo inválido");
  std::vector<uint8_t> raw((n/bs)*ts);
  stream.read((char*)raw.data(), (std::streamsize)raw.size());
  const size_t CH = 256*1024;
  std::vector<float> tmp(std::min(CH, n));
  size_t done = 0;
  while (done < n) {
    size_t k = std::min(CH, n - done);
    k = (k / bs) * bs; if (k == 0) k = bs;
    luna_dq_dispatch(info.type, raw.data() + (done/bs)*ts, tmp.data(), k);
    for (size_t i=0;i<k;++i) out[done+i] = fp32_to_fp16(tmp[i]);
    done += k;
  }
  return out;
}

std::vector<uint8_t> GgufFile::read_raw(const TensorInfo& info) {
  size_t n = 1;
  for (auto d : info.shape) n *= d;

  const size_t bs = ggml_block_size(info.type);
  const size_t ts = ggml_type_size(info.type);
  if (bs == 0 || ts == 0)
    throw std::runtime_error(std::string("read_raw: tipo inválido: ") +
                             ggml_type_name(info.type));
  if (n % bs != 0)
    throw std::runtime_error("read_raw: n não múltiplo do block size");

  const size_t nbytes = (n / bs) * ts;
  std::vector<uint8_t> out(nbytes);
  stream.seekg(static_cast<std::streamoff>(data_offset + info.offset));
  stream.read(reinterpret_cast<char*>(out.data()),
              static_cast<std::streamsize>(nbytes));
  if (!stream)
    throw std::runtime_error("read_raw: leitura truncada");
  return out;
}

}  // namespace luna::io
