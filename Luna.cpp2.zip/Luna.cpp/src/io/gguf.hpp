#pragma once

#include <cstdint>
#include <fstream>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>

namespace luna::io {

enum class GgmlType : uint32_t {
  F32 = 0, F16 = 1, Q4_0 = 2, Q4_1 = 3, Q5_0 = 6, Q5_1 = 7,
  Q8_0 = 8, Q8_1 = 9, Q2_K = 10, Q3_K = 11, Q4_K = 12,
  Q5_K = 13, Q6_K = 14, Q8_K = 15, BF16 = 30,
};

const char* ggml_type_name(GgmlType t);
size_t ggml_type_size(GgmlType t);
size_t ggml_block_size(GgmlType t);

struct TensorInfo {
  std::string name;
  std::vector<uint64_t> shape;
  GgmlType type = GgmlType::F32;
  uint64_t offset = 0;
};

using MetaValue = std::variant<
  uint8_t, int8_t, uint16_t, int16_t, uint32_t, int32_t,
  float, bool, std::string, uint64_t, int64_t, double,
  std::vector<std::string>, std::vector<int32_t>, std::vector<float>
>;

struct GgufFile {
  uint32_t version = 0;
  uint64_t alignment = 32;
  std::unordered_map<std::string, MetaValue> metadata;
  std::vector<TensorInfo> tensors;
  std::unordered_map<std::string, size_t> tensor_index;
  std::ifstream stream;
  uint64_t data_offset = 0;

  bool open(const std::string& path);
  const TensorInfo* find(const std::string& name) const;

  std::vector<float>    read_f32(const TensorInfo& info);
  std::vector<uint16_t> read_f16(const TensorInfo& info);
  std::vector<uint8_t>  read_raw(const TensorInfo& info);   // F16 raw bits

  // Devolve os bytes crus do tensor como estão no arquivo (sem desquantizar).
  // Para tensores quantizados, o tamanho é (n / block_size) * type_size.

  template <typename T>
  T meta(const std::string& key, T fallback = T{}) const {
    auto it = metadata.find(key);
    if (it == metadata.end()) return fallback;
    if (auto p = std::get_if<T>(&it->second)) return *p;
    return fallback;
  }

  std::string arch() const;
};

void luna_dq_dispatch(GgmlType t, const uint8_t* p, float* y, size_t n);

inline float fp16_to_fp32(uint16_t h) {
  uint32_t s = (h >> 15) & 1;
  uint32_t e = (h >> 10) & 0x1F;
  uint32_t m = h & 0x3FF;
  uint32_t f;
  if (e == 0) {
    if (m == 0) f = s << 31;
    else {
      e = 127 - 15 + 1;
      while (!(m & 0x400)) { m <<= 1; --e; }
      m &= 0x3FF;
      f = (s << 31) | (e << 23) | (m << 13);
    }
  } else if (e == 31) {
    f = (s << 31) | 0x7F800000 | (m << 13);
  } else {
    f = (s << 31) | ((e + 127 - 15) << 23) | (m << 13);
  }
  float out;
  std::memcpy(&out, &f, 4);
  return out;
}

inline uint16_t fp32_to_fp16(float v) {
  uint32_t f; std::memcpy(&f, &v, 4);
  uint32_t s = (f >> 31) & 1;
  int32_t  e = ((f >> 23) & 0xFF) - 127 + 15;
  uint32_t m = f & 0x7FFFFF;
  if (e <= 0) return (uint16_t)(s << 15);
  if (e >= 31) return (uint16_t)((s << 15) | 0x7C00);
  return (uint16_t)((s << 15) | (e << 10) | (m >> 13));
}

}  // namespace luna::io
